class vanrednoZauzece{
    datum;
    pocetak;
    kraj;
    naziv;
    predavac;
    constructor(datum, pocetak, kraj, naziv, predavac){
        this.datum = datum;
        this.pocetak = pocetak;
        this.kraj = kraj;
        this.naziv = naziv;
        this.predavac = predavac;
    }
    }
module.exports = vanrednoZauzece;
