function ucitajSaServera(fnCallback){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200){
            var jsonRez = JSON.parse(ajax.responseText);
            fnCallback(jsonRez.zauzeca.periodicna,jsonRez.zauzeca.vanredna);
            pozivObojiZauzeca();
        }
        else if (ajax.readyState == 4)
            fnCallback(ajax.statusText,null);
    }
    ajax.open("POST","http://localhost:8080/rezervacija.html",true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send();
 }
function posaljiPeriodicnoZauzece(zauzece){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200){
            ucitajSaServera(Kalendar.ucitajPodatke);
        }
        else if (ajax.readyState == 4 && ajax.status == 201)
        alert(ajax.responseText);

        else if(ajax.readyState == 4){}
    }
    ajax.open("POST","http://localhost:8080/rezervacija.html/periodicno",true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify(zauzece));
}
function posaljiVanrednoZauzece(zauzece2){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200){
            ucitajSaServera(Kalendar.ucitajPodatke);
        }
        else if (ajax.readyState == 4 && ajax.status == 201)
        alert(ajax.responseText);

        else if(ajax.readyState == 4){}
    }
    ajax.open("POST","http://localhost:8080/rezervacija.html/vanredno",true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify(zauzece2));
}

function vratiSlike(nizSlika, sl1, sl2, sl3){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200){
            var nazivi = JSON.parse(ajax.responseText);
            if(nazivi.length == 3){
            sl1.src = "http://localhost:8080/Photos/" + nazivi[0];
            sl2.src = "http://localhost:8080/Photos/" + nazivi[1];
            sl3.src = "http://localhost:8080/Photos/" + nazivi[2];
            nizSlika.push(nazivi[0]);
            nizSlika.push(nazivi[1]);
            nizSlika.push(nazivi[2]);
            }
            else if(nazivi.length == 2){
                sl1.src = "http://localhost:8080/Photos/" + nazivi[0];
                sl2.src = "http://localhost:8080/Photos/" + nazivi[1];
                sl3.src = "";
                nizSlika.push(nazivi[0]);
                nizSlika.push(nazivi[1]);
            }
            else if(nazivi.length == 1){
                sl1.src = "http://localhost:8080/Photos/" + nazivi[0];
                sl2.src = "";
                sl3.src = "";
                nizSlika.push(nazivi[0]);
            }
        }
        else if (ajax.readyState == 4 && ajax.status == 201)
        alert(ajax.responseText);

        else if(ajax.readyState == 4){}
    }
    ajax.open("POST","http://localhost:8080/pocetna.html/slike");
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify(nizSlika));
}


function vratiOsoblje(lista){
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        if(xhr.readyState == 4 && this.status == 200){
            var osoblje = JSON.parse(this.responseText);
            for(i=0; i<osoblje.length; i++){
                var option = document.createElement("option");
                option.text = osoblje[i].ime + " " + osoblje[i].prezime + " " + osoblje[i].uloga;
                lista.add(option);
            }
            
        }
        else if (xhr.readyState == 4 && this.status == 201)
        alert(this.responseText);

        else if(xhr.readyState == 4){}

    }
    xhr.open('GET', "http://localhost:8080/osoblje");
    xhr.responseType = "text";
    xhr.send();
}

function vratiSale(lista){
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        if(xhr.readyState == 4 && this.status == 200){
            var sale = JSON.parse(this.responseText);
            for(i=0; i<sale.length; i++){
                var option = document.createElement("option");
                option.text = sale[i].naziv;
                lista.add(option);
            }
        }
        else if (xhr.readyState == 4 && this.status == 201)
        alert(this.responseText);

        else if(xhr.readyState == 4){}

    }
    xhr.open('GET', "http://localhost:8080/sale");
    xhr.responseType = "text";
    xhr.send();
}

function vratiOsobeuSalama(tabela){
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        if(xhr.readyState == 4 && this.status == 200){
            var data = JSON.parse(this.responseText);
            var listaOsoba = data.liste.listaOsoba;
            var listaSala = data.liste.listaSala;
            for(i=0; i<listaOsoba.length; i++){
                var row = tabela.insertRow(i+1);
                var cell1 = row.insertCell(0);
                var cell2 = row.insertCell(1);
                cell1.innerHTML = listaOsoba[i];
                cell2.innerHTML = listaSala[i];
            }
            
        }
        else if (xhr.readyState == 4 && this.status == 201)
        alert(this.responseText);

        else if(xhr.readyState == 4){}

    }
    xhr.open('GET', "http://localhost:8080/osobljeUSalama");
    xhr.responseType = "text";
    xhr.send();
}