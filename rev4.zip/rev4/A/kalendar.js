class periodicnoZauzece {
    dan;
    semestar;
    pocetak;
    kraj;
    naziv;
    predavac;
    constructor(dan, semestar, pocetak, kraj, naziv, predavac){
        this.dan = dan;
        this.semestar = semestar;
        this.pocetak = pocetak;
        this.kraj = kraj;
        this.naziv = naziv;
        this.predavac = predavac;
    }
    }
class vanrednoZauzece{
    datum;
    pocetak;
    kraj;
    naziv;
    predavac;
    constructor(datum, pocetak, kraj, naziv, predavac){
        this.datum = datum;
        this.pocetak = pocetak;
        this.kraj = kraj;
        this.naziv = naziv;
        this.predavac = predavac;
    }
    }
class zauzetiDan{
    datum;
    sala;
    pocetak;
    kraj;
    vanredan;
    ispisan;
    constructor(datum, sala, pocetak, kraj, vanredan, ispisan){
        this.datum = datum;
        this.vanredan = vanredan;
        this.ispisan = ispisan;
        this.sala = sala;
        this.pocetak = pocetak;
        this.kraj = kraj;
    }
}
    

let Kalendar = (function(){
    var mjeseci= ["Januar", "Februar", "Mart", "April", "Maj", "Juni", "Juli", "August", "Septembar", "Oktobar", "Novembar", "Decembar"];
    var datum = new Date();
    var zauzetiDaniLista = [];

    //
    //ovdje idu privatni atributi
    //
    function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj){
        var tabela = kalendarRef.children[1];
        var redoviTabele = [];
        zauzetiDaniLista.forEach(element => {
            if(element.vanredan == true){
                element.ispisan = false;
            }
        });
        for(var i=1; i<=6; i++){
            redoviTabele[i-1] = tabela.children[i];
        }
        for(var i=0; i<redoviTabele.length; i++){
            var nizCelija = redoviTabele[i].children;
            for(var j=0; j<nizCelija.length; j++){
                nizCelija[j].children[1].className = "status statusSlobodan";
            }
        }
        for(var i=1; i<=6; i++){
            redoviTabele[i-1] = tabela.children[i];
        }
        for(var i=0; i<redoviTabele.length; i++){
            var nizCelija = redoviTabele[i].children;
            for(var j=0; j<nizCelija.length; j++){
                if(nizCelija[j].classList.contains("cellPrazna")) continue;
                var date = new Date(datum.getFullYear(), mjesec, nizCelija[j].children[0].innerHTML);
                zauzetiDaniLista.forEach(element => {
                    if(element.datum.getDay() == date.getDay() && element.datum.getDate() == date.getDate() && element.datum.getMonth() == mjesec && element.sala == sala && compareTime(element.pocetak, pocetak, element.kraj, kraj)){
                        if(element.vanredan == true && element.ispisan == false){
                        nizCelija[j].children[1].className = "status statusZauzet";
                        element.ispisan = true;
                        }
                        else if(element.vanredan == false){
                            nizCelija[j].children[1].className = "status statusZauzet";
                        }
                    }
                });
            }
        }
    }
    function compareTime(pocetak1, pocetak2, kraj1, kraj2){
        //trazeno ponasanje ako je pocetak1<pocetak2 && kraj1>kraj2 || pocetak1<pocetak2 && kraj1<kraj2 || pocetak1>pocetak2 && kraj1<kraj2 
        var satPocetak1 = parseInt(pocetak1[0]+pocetak1[1]+pocetak1[3]+pocetak1[4]);

        var satPocetak2 = parseInt(pocetak2[0]+pocetak2[1]+pocetak2[3]+pocetak2[4]);

        var satKraj1 = parseInt(kraj1[0]+kraj1[1]+kraj1[3]+kraj1[4]);

        var satKraj2 = parseInt(kraj2[0]+kraj2[1]+kraj2[3]+kraj2[4]);


        if(satPocetak2>satPocetak1 && satKraj2<satKraj1) return true;
        else if(satPocetak2<=satPocetak1 && satKraj2>=satKraj1) return true;
        else if(satPocetak2>=satPocetak1 && satPocetak2<=satKraj1) return true;
        else if(satKraj2>=satPocetak1 && satKraj2<=satKraj1) return true;
        else if(satPocetak1 == satPocetak2 && satKraj1 == satKraj2) return true;
        else return false;
    }
    function compareDate(str1){
        if(str1.charAt(1) == '.'){
            var pom = '0' + str1;
            str1 = pom;
        }
        if(str1.charAt(4) == '.'){
            var st = str1.substring(0, 3);
            var st2 = str1.substring(3, ); 
            var pom = st + "0";
            str1 = pom + st2;
        }
        var dt1   = parseInt(str1.substring(0,2));
        var mon1  = parseInt(str1.substring(3,5));
        var yr1   = parseInt(str1.substring(6,10));
        var date1 = new Date(yr1, mon1-1, dt1);
        return date1;
    }
    function ucitajPodatkeImpl(periodicna, vanredna){
        
        //neki podaci
        zauzetiDaniLista = [];
        
        //ubacivanje vanredih dana u listu
        vanredna.forEach(element => {
            zauzetiDaniLista.push(new zauzetiDan(compareDate(element.datum), element.naziv, element.pocetak, element.kraj, true, false));
        });

        //za svaki periodicni dan stavljam sve dane u cijelom semestru
        periodicna.forEach(element =>{
            registrujDane(element.dan, element.semestar, element.naziv, element.pocetak, element.kraj);
        });


    }
    function registrujDane(danuSedmici, semestar, sala, pocetak, kraj){
        var godina = new Date().getFullYear();
        if(semestar == 'zimski'){
            for(var i=9; i<=11; i++){
                var datum = new Date(godina, i);
                var brojDanapomocna = getDaysInMonth(i, godina);
                for(var j=0; j<brojDanapomocna; j++){
                    var day = datum.getDay();
                    day = (day===0) ? 7 : day;
                    day--;
                    if(day == danuSedmici){   
                    zauzetiDaniLista.push(new zauzetiDan(datum, sala, pocetak, kraj, false, false));
                    }
                    datum = new Date(godina, i, datum.getDate()+1);
                }
                
            }
            var i=0;
            var datum = new Date(godina, i);
            
            
                var brojDanapomocna = getDaysInMonth(i, godina);
                for(var j=0; j<brojDanapomocna; j++){
                    var day = datum.getDay();
                    day = (day===0) ? 7 : day;
                    day--;
                    if(day == danuSedmici){
                    zauzetiDaniLista.push(new zauzetiDan(datum, sala, pocetak, kraj, false, false));
                    }
                    datum = new Date(godina, i, datum.getDate()+1);
                }
        }
        else if(semestar == 'ljetni'){
            for(var i=1; i<=4; i++){
                var datum = new Date(godina, i);
                var brojDanapomocna = getDaysInMonth(i, godina);
                for(var j=0; j<brojDanapomocna; j++){
                    var day = datum.getDay();
                    day = (day===0) ? 7 : day;
                    day--;
                    if(day == danuSedmici){
                    zauzetiDaniLista.push(new zauzetiDan(datum, sala, pocetak, kraj, false, false));
                    }
                    datum = new Date(godina, i, datum.getDate()+1);
                }
                
            }
        }
        
    }
    function iscrtajKalendarImpl(kalendarRef, mjesec){
        var month = mjesec;
        var year = datum.getFullYear();
        month++;
        var day = new Date(year + "-" + month + "-01").getDay();
        day = (day===0) ? 7 : day;
        day--;

        var brojPraznihDana = day;
        var brojDana = getDaysInMonth(mjesec, year);
        kalendarRef.children[0].innerHTML = mjeseci[mjesec];
        var tabela = kalendarRef.children[1];
        var redoviTabele = [];
        for(var i=1; i<=6; i++){
            redoviTabele[i-1] = tabela.children[i];
        }
        var pomocniDani = 1;
        var prazniDani = 1;
        for(var i=0; i<redoviTabele.length; i++){
            var nizCelija = redoviTabele[i].children;
            for(var j=0; j<nizCelija.length; j++){
                if(prazniDani <= brojPraznihDana){
                    nizCelija[j].className = "cell cellPrazna";
                    nizCelija[j].children[1].className = "status statusSlobodan";
                    prazniDani++;
                }
                else if(pomocniDani <= brojDana){
                    nizCelija[j].className = "cell";
                    nizCelija[j].children[1].className = "status statusSlobodan";
                    nizCelija[j].children[0].innerHTML = pomocniDani;
                    pomocniDani++;
                }
                else{
                    nizCelija[j].className = "cell cellPrazna";
                    nizCelija[j].children[1].className = "status statusSlobodan";
                }
            }
        }

    }
    function getDaysInMonth(month, year) {
        var month2 = month;
        return new Date(year, month2+1, 0).getDate();
      };
    return {
    obojiZauzeca: obojiZauzecaImpl,
    ucitajPodatke: ucitajPodatkeImpl,
    iscrtajKalendar: iscrtajKalendarImpl
    }
    }());