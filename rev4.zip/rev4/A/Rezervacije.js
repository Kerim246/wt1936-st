const Sequelize = require("sequelize");
module.exports = function(sequelize, DataTypes){
    const Rezervacije = sequelize.define("Rezervacije", {
        termin:{
            type: Sequelize.INTEGER
        },
        sala:Sequelize.INTEGER,
        osoba:Sequelize.INTEGER
    })
    return Rezervacije;
};