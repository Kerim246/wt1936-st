let assert = chai.assert;
describe('Kalendar', function(){
    describe('obojiZauzeca()', function(){
        it('Kada podaci nisu ucitani, ne boji niti jedan dan', function(){
            let kalendar = document.getElementById('kalendar');
            Kalendar.obojiZauzeca(kalendar, 10, "0-01", "12:00", "13:00");
            var tabela = kalendar.children[1];
            var redoviTabele = [];
            var broj =0;
        for(var i=1; i<=6; i++){
            redoviTabele[i-1] = tabela.children[i];
        }
        for(var i=0; i<redoviTabele.length; i++){
            var nizCelija = redoviTabele[i].children;
            for(var j=0; j<nizCelija.length; j++){
                if(nizCelija[j].children[1].classList.contains('statusZauzet')) broj++;
            }
        }
        assert.equal(broj, 0, "Broj obojenih dana treba biti jednak nuli");
        });
        
        it('Sa duplim zauzecima unutar liste vanredni dani', function(){
            let kalendar = document.getElementById('kalendar');
            var periodicniDani = [];
            var vandredniDani = [new vanrednoZauzece("12.11.2019", '15:00', '18:00', '0-01', 'Bakir Izetbegovic'), new vanrednoZauzece("12.11.2019", '15:00', '18:00', '0-01', 'Bakir Izetbegovic')];
            Kalendar.ucitajPodatke(periodicniDani, vandredniDani);
            Kalendar.obojiZauzeca(kalendar, 10, "0-01", "15:00", "18:00");
            var tabela = kalendar.children[1];
            var redoviTabele = [];
            var broj =0;
        for(var i=1; i<=6; i++){
            redoviTabele[i-1] = tabela.children[i];
        }
        for(var i=0; i<redoviTabele.length; i++){
            var nizCelija = redoviTabele[i].children;
            for(var j=0; j<nizCelija.length; j++){
                if(nizCelija[j].children[1].classList.contains('statusZauzet')) broj++;
                
            }
        }
        assert.equal(broj, 1, "Broj obojenih dana treba biti jednak 1");
        });

        it("Kada u podacima postoji zauzece termina ali u drugom semestru", function(){
            let kalendar = document.getElementById('kalendar');
            var periodicniDani = [new periodicnoZauzece(0, 'ljetni', '15:00', '18:00', '0-01', 'Huse Fatkic')];
            var vandredniDani = [];
            Kalendar.ucitajPodatke(periodicniDani, vandredniDani);
            Kalendar.obojiZauzeca(kalendar, 10, "0-01", "15:00", "18:00");
            var tabela = kalendar.children[1];
            var redoviTabele = [];
            var broj =0;
        for(var i=1; i<=6; i++){
            redoviTabele[i-1] = tabela.children[i];
        }
        for(var i=0; i<redoviTabele.length; i++){
            var nizCelija = redoviTabele[i].children;
            for(var j=0; j<nizCelija.length; j++){
                if(nizCelija[j].children[1].classList.contains('statusZauzet')) broj++;
                
            }
        }
        assert.equal(broj, 0, "Broj obojenih dana treba biti jednak 0");
        });

        it("Kada u podacima postoji zauzece ali u drugom mjesecu", function(){
            let kalendar = document.getElementById('kalendar');
            var periodicniDani = [];
            var vandredniDani = [new vanrednoZauzece("12.12.2019", '15:00', '18:00', '0-01', 'Bakir Izetbegovic')];
            Kalendar.ucitajPodatke(periodicniDani, vandredniDani);
            Kalendar.obojiZauzeca(kalendar, 10, "0-01", "15:00", "18:00");
            var tabela = kalendar.children[1];
            var redoviTabele = [];
            var broj =0;
        for(var i=1; i<=6; i++){
            redoviTabele[i-1] = tabela.children[i];
        }
        for(var i=0; i<redoviTabele.length; i++){
            var nizCelija = redoviTabele[i].children;
            for(var j=0; j<nizCelija.length; j++){
                if(nizCelija[j].children[1].classList.contains('statusZauzet')) broj++;
                
            }
        }
        assert.equal(broj, 0, "Broj obojenih dana treba biti jednak 0");
        });

        it("Pozivanje kada su u podacima svi termini zauzeti, ocekivano da svi dani budu obojeni", function(){
            let kalendar = document.getElementById('kalendar');
            var periodicniDani = [new periodicnoZauzece(0, 'zimski', '15:00', '18:00', '0-01', 'Huse Fatkic'),
                                new periodicnoZauzece(1, 'zimski', '15:00', '18:00', '0-01', 'Huse Fatkic'),
                                new periodicnoZauzece(2, 'zimski', '15:00', '18:00', '0-01', 'Huse Fatkic'),
                                new periodicnoZauzece(3, 'zimski', '15:00', '18:00', '0-01', 'Huse Fatkic'),
                                new periodicnoZauzece(4, 'zimski', '15:00', '18:00', '0-01', 'Huse Fatkic'),
                                new periodicnoZauzece(5, 'zimski', '15:00', '18:00', '0-01', 'Huse Fatkic'),
                                new periodicnoZauzece(6, 'zimski', '15:00', '18:00', '0-01', 'Huse Fatkic')];
            var vandredniDani = [];
            Kalendar.ucitajPodatke(periodicniDani, vandredniDani);
            Kalendar.obojiZauzeca(kalendar, 10, "0-01", "15:00", "18:00");
            var tabela = kalendar.children[1];
            var redoviTabele = [];
            var broj =0;
        for(var i=1; i<=6; i++){
            redoviTabele[i-1] = tabela.children[i];
        }
        for(var i=0; i<redoviTabele.length; i++){
            var nizCelija = redoviTabele[i].children;
            for(var j=0; j<nizCelija.length; j++){
                if(nizCelija[j].children[1].classList.contains('statusZauzet')) broj++;
                
            }
        }
        assert.equal(broj, 30, "Broj obojenih dana treba biti jednak 0");
        });
        it("Dva puta pozivanje funkcije, zauzece treba ostati isto", function(){
            let kalendar = document.getElementById('kalendar');
            var periodicniDani = [];
            var vandredniDani = [new vanrednoZauzece("12.11.2019", '15:00', '18:00', '0-01', 'Bakir Izetbegovic')];
            Kalendar.ucitajPodatke(periodicniDani, vandredniDani);
            Kalendar.obojiZauzeca(kalendar, 10, "0-01", "15:00", "18:00");
            Kalendar.obojiZauzeca(kalendar, 10, "0-01", "15:00", "18:00");
            var tabela = kalendar.children[1];
            var redoviTabele = [];
            var broj =0;
        for(var i=1; i<=6; i++){
            redoviTabele[i-1] = tabela.children[i];
        }
        for(var i=0; i<redoviTabele.length; i++){
            var nizCelija = redoviTabele[i].children;
            for(var j=0; j<nizCelija.length; j++){
                if(nizCelija[j].children[1].classList.contains('statusZauzet')) broj++;
                
            }
        }
        assert.equal(broj, 1, "Broj obojenih dana treba biti jednak 1");
        });

        it("Pozivanje ucitajPodatke, obojiZauzeca, ucitajPodatke, obojiZauzeca", function(){
            let kalendar = document.getElementById('kalendar');
            var periodicniDani = [new periodicnoZauzece(0, 'zimski', '15:00', '18:00', '0-01', 'Huse Fatkic')];
            var vandredniDani = [];
            Kalendar.ucitajPodatke(periodicniDani, vandredniDani);
            Kalendar.obojiZauzeca(kalendar, 10, "0-01", "15:00", "18:00");
            periodicniDani = [];
            vandredniDani = [new vanrednoZauzece("12.11.2019", '15:00', '18:00', '0-01', 'Bakir Izetbegovic')];
            Kalendar.ucitajPodatke(periodicniDani, vandredniDani);
            Kalendar.obojiZauzeca(kalendar, 10, "0-01", "15:00", "18:00");
            var tabela = kalendar.children[1];
            var redoviTabele = [];
            var broj =0;
        for(var i=1; i<=6; i++){
            redoviTabele[i-1] = tabela.children[i];
        }
        for(var i=0; i<redoviTabele.length; i++){
            var nizCelija = redoviTabele[i].children;
            for(var j=0; j<nizCelija.length; j++){
                if(nizCelija[j].children[1].classList.contains('statusZauzet')) broj++;
                
            }
        }
        assert.equal(broj, 1, "Broj obojenih dana treba biti jednak 1");
        });

        describe('iscrtajKalendar()', function(){
        it("Pozivanje metode za mjesec od 30 dana (npr Juni)", function(){
            let kalendar = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(kalendar, 5);
            var tabela = kalendar.children[1];
            var redoviTabele = [];
            var broj =0;
        for(var i=1; i<=6; i++){
            redoviTabele[i-1] = tabela.children[i];
        }
        for(var i=0; i<redoviTabele.length; i++){
            var nizCelija = redoviTabele[i].children;
            for(var j=0; j<nizCelija.length; j++){
                if(!nizCelija[j].classList.contains('cellPrazna')) broj++;
                
            }
        }
        assert.equal(broj, 30, "Broj obojenih dana treba biti jednak 30");
        });
        it("Pozivanje metode za mjesec od 31 dana (npr Oktobar)", function(){
            let kalendar = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(kalendar, 9);
            var tabela = kalendar.children[1];
            var redoviTabele = [];
            var broj =0;
        for(var i=1; i<=6; i++){
            redoviTabele[i-1] = tabela.children[i];
        }
        for(var i=0; i<redoviTabele.length; i++){
            var nizCelija = redoviTabele[i].children;
            for(var j=0; j<nizCelija.length; j++){
                if(!nizCelija[j].classList.contains('cellPrazna')) broj++;
                
            }
        }
        assert.equal(broj, 31, "Broj obojenih dana treba biti jednak 31");
        });
        it("Pozivanje metode za trenutni mjesec (Novembar) 1. dan u petak", function(){
            let kalendar = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(kalendar, 10);
            var tabela = kalendar.children[1];
            var redoviTabele = [];
            var broj =0;
            var brakovan = 0;
        for(var i=1; i<=6; i++){
            redoviTabele[i-1] = tabela.children[i];
        }
        for(var i=0; i<redoviTabele.length; i++){
            var nizCelija = redoviTabele[i].children;
            for(var j=0; j<nizCelija.length; j++){
                if(nizCelija[j].classList.contains('cellPrazna')) broj++;
                else{
                    brakovan = true;
                    break;
                }
            }
            if(brakovan) break;
        }
        assert.equal(broj, 4, "Ako ima 4 prazne celije, prva neprazna pada u petak");
        });
        it("Pozivanje metode za trenutni mjesec (Novembar) 30. dan u subotu", function(){
            let kalendar = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(kalendar, 10);
            var tabela = kalendar.children[1];
            var redoviTabele = [];
            var broj =0;
            var breakVar = false;
            var presloNaPune = 0;
        for(var i=1; i<=6; i++){
            redoviTabele[i-1] = tabela.children[i];
        }
        for(var i=0; i<redoviTabele.length; i++){
            var nizCelija = redoviTabele[i].children;
            for(var j=0; j<nizCelija.length; j++){
                if(nizCelija[j].classList.contains('cellPrazna')) broj++;
                else{
                    presloNaPune = true;
                    broj++;
                }
                if(presloNaPune && nizCelija[j].classList.contains('cellPrazna')){
                    breakVar = true;
                    break;
                }
            }
            if(breakVar) break;
        }
        broj--;
        assert.equal(broj, 34, "Ukoliko ima ukupno 34 celije, 34-ta celija pada na subotu");
        });
        it("Pozivanje metode za mjesec Januar, koji pocinje od utorka", function(){
            let kalendar = document.getElementById('kalendar');
            Kalendar.iscrtajKalendar(kalendar, 0);
            var tabela = kalendar.children[1];
            var redoviTabele = [];
            var broj =0;
            var brakovan = 0;
        for(var i=1; i<=6; i++){
            redoviTabele[i-1] = tabela.children[i];
        }
        for(var i=0; i<redoviTabele.length; i++){
            var nizCelija = redoviTabele[i].children;
            for(var j=0; j<nizCelija.length; j++){
                if(nizCelija[j].classList.contains('cellPrazna')) broj++;
                else{
                    brakovan = true;
                    break;
                }
            }
            if(brakovan) break;
        }
        assert.equal(broj, 1, "Ako ima 1 praznu celiju, prva neprazna pada u utorak");
        });

    });
    });
    
});