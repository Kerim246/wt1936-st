function ucitajOsobljeUsalama(){
    var tabela = document.getElementById("tabela");
    vratiOsobeuSalama(tabela);
}

function onWindowLoad(){
    setInterval(ucitajOsobljeUsalama, 30000);
}