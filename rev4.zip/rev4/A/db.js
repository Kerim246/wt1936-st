const Sequelize = require("sequelize");
const sequelize = new Sequelize("DBWT19", "root", "", {host:"127.0.0.1", dialect:"mysql", logging:false});
const db={}

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.osoblje = sequelize.import(__dirname+"/Osoblje.js");
db.rezervacije = sequelize.import(__dirname+"/Rezervacije.js");
db.termin = sequelize.import(__dirname+"/Termin.js");
db.sala = sequelize.import(__dirname+"/Sala.js");

db.osoblje.hasMany(db.rezervacije, {foreignKey: "osoba"});
db.rezervacije.belongsTo(db.osoblje, {foreignKey: "osoba"});

db.rezervacije.belongsTo(db.termin, {foreignKey: "termin"});
db.termin.hasOne(db.rezervacije, {foreignKey: "termin"});

db.sala.hasMany(db.rezervacije, {foreignKey: "sala"});
db.rezervacije.belongsTo(db.sala, {foreignKey: "sala"});

db.sala.belongsTo(db.osoblje, {foreignKey: "zaduzenaOsoba"});
db.osoblje.hasOne(db.sala, {foreignKey: "zaduzenaOsoba"});

module.exports = db;