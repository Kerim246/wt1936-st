// testovi se pokrecu sa npx mocha testoviS4.js u terminalu!!
let Osoblje = require('./Osoblje.js');
let chai = require('chai');
let chaiHttp = require('chai-http');
let app = require('./index.js');
let should = chai.should();
let assert = chai.assert;
const kreiranje = require("./pravljenjeTabela.js");
const db = require("./db.js");
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;

chai.use(chaiHttp);

describe('/GET /osoblje', () => {
        it('Treba da vrati svo osoblje (3 osobe u bazi)', (done) => {
          chai.request(app)
              .get('/osoblje')
              .end((err, res) => {
                  var osoblje = JSON.parse(res.text);
                  var broj = osoblje.length;
                assert.equal(broj, 3, "Broj vraćenih uposlenika treba biti 3");
                done();
              });
        });
      });

//Ostale testove nisam ni radio, imao sam problem s tim sto su se testovi izvrsavali prije nego sto se baza kreira i podaci ucitaju
// pa mi je bacalo gresku, iako bi radili, ali nisam znao kako da to popravim nikako...
// Ovaj test sa osobljem prolazi, jer se tabel Osoblje prva kreira i onda ima vremena.