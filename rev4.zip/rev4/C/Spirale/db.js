const Sequelize = require("sequelize");

const sequelize = new Sequelize("DBWT19", "root", "root", {
  host: "127.0.0.1",
  dialect: "mysql",
  logging: false
});
const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

//import modela
db.osoblje = sequelize.import(__dirname + "/models/osoblje.js");
db.rezervacija = sequelize.import(__dirname + "/models/rezervacija.js");
db.termin = sequelize.import(__dirname + "/models/termin.js");
db.sala = sequelize.import(__dirname + "/models/sala.js");

//relacije
//rezervacija - osoblje
db.osoblje.hasMany(db.rezervacija, {
  foreignKey: "osoba"
});
db.rezervacija.belongsTo(db.osoblje, { as: "osobaRezervacija", foreignKey: "osoba" });

//rezervacija - termin
db.rezervacija.belongsTo(db.termin, { as: "terminRezervacija", foreignKey: "termin" });
db.termin.hasOne(db.rezervacija, {
  foreignKey: "termin"
});

//rezervacija - sala
db.sala.hasMany(db.rezervacija, {
  foreignKey: "sala"
});
db.rezervacija.belongsTo(db.sala, { as: "rezervacijaSala", foreignKey: "sala" });

//sala - osoblje
db.sala.belongsTo(db.osoblje, { as: "osobaSala", foreignKey: "zaduzenaOsoba" });
db.osoblje.hasOne(db.sala, {
  foreignKey: "zaduzenaOsoba"
});

module.exports = db;
