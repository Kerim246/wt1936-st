// U fajlu index.js se nalazi kod serverskih funkcionalnosti
// Kada se pokrene "​node index.js" potreno je da se sve stranice ispravno prikazuju
// kada se pristupi ​http://localhost:8080/​. 
//​Sve stranice sa prethodnih spirala se trebaju prikazivati ispravno. 
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const path = require('path');
const url = require('url');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

app.use(express.static(__dirname));

app.get('/zauzeca', (req, res) => {
    res.sendFile(path.join(__dirname, 'zauzeca.json'));
});


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'pocetna.html'));
});

function imaLiPreklapanja(rezervacija) {
    // ima li preklapanja...
    return false;
}

var svaZauzeca = null;

app.post('/zauzeca', (req, res) => { // u req imamo JSON objekat
    var rezervacija = req.body
    var preklapanje = imaLiPreklapanja(rezervacija);
    if(!preklapanje) {
        
            
        fs.readFile('zauzeca.json', (err, data) => {
            if (err)  { 
                console.error("Belaj! Neuspješno citanje iz zauzeca!");
                throw err;
            }
            svaZauzeca = JSON.parse(data);
            
        });

        if(svaZauzeca == null) {
            //...
        }
        
        //ako su ucitana zauzeca
        else {
            if(Object.keys(rezervacija).length == 6) // ako je periodicna
                svaZauzeca["periodicna"].push(rezervacija);
            else
                svaZauzeca["vanredna"].push(rezervacija);
                let data = JSON.stringify(svaZauzeca, null, 2);

            fs.writeFile('zauzeca.json', data, (err) => {
                if (err) throw err;
            });
        }

        
    }
    res.sendFile(path.join(__dirname, 'zauzeca.json'));
});

app.listen(8080);
