let Pozivi = (
    function(){

        function ucitajZauzecaImpl() {
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {// Anonimna funkcija
               if (ajax.readyState == 4 && ajax.status == 200){
                    var json = JSON.parse(ajax.responseText); 
                    
                    mojaPeriodicna = json["periodicna"];
                    mojaVanredna = json["vanredna"];
               }
           }
           ajax.open("GET","http://localhost:8080/zauzeca",true);
           ajax.setRequestHeader("Content-Type", "application/json");
           ajax.send();
        }
        
        
        function ucitajPocetnaImpl() {
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {// Anonimna funkcija
               if (ajax.readyState == 4 && ajax.status == 200){
                    // ništa...
               }
           }
           ajax.open("GET","http://localhost:8080/",true);
           ajax.setRequestHeader("Content-Type", "text/html");
           ajax.send();
        }



        // rezervacija je JSON objekat koji
        function rezervisiSaluImpl(rezervacija) {
            // saljemo POST zahtjev na server (/zauzeca)
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {// Anonimna funkcija
               if (ajax.readyState == 4 && ajax.status == 200){
                   // kada nam server vrati JSON file "zauzeca.json"
                   var json = JSON.parse(ajax.responseText); // dobivamo objekat iz JSON  file-a
                   mojaPeriodicna = json["periodicna"]; // azuriramo zauzeca
                   mojaVanredna = json["vanredna"];
                   var kal = document.getElementById("mojKalendar");
                   var mjesec = kal.caption.innerText;
                   Kalendar.iscrtajKalendar(kal,mjesec); // azuriramo samo trenutni mjesec jer ce se sljedeci/prethodni azurirati klikom na dugmad
               }
          
           }
           ajax.open("POST","http://localhost:8080/zauzeca",true);
           ajax.setRequestHeader("Content-Type", "application/json");
           ajax.send(JSON.stringify(rezervacija)); // moramo poslati string kao parametar
        }



    
        return {

            ucitajZauzeca: ucitajZauzecaImpl,
            ucitajPocetna: ucitajPocetnaImpl,
            rezervisiSalu: rezervisiSaluImpl
           
        }

    }());


