// ******************************OSOBLJE****************************************************************

const Sequelize = require("sequelize");

module.exports = function(sequelize, DataTypes) {
    const Osoblje = sequelize.define('Osoblje', { // kreiramo model osoblje
        id:{
            type: Sequelize.INTEGER,
            allowNull: false,
            primaryKey: true
        },
        ime:{
            type: Sequelize.STRING
        },
        prezime:{
            type: Sequelize.STRING
        },
        uloga:{
            type:Sequelize.STRING
        }
    },
    {
        // Ovdje mozemo dodati metode po potrebi
        freezeTableName: true   // zelimo isti naziv tabela kao i modela
    });
    return Osoblje;

};
//module.exports=Osoblje;



