window.onload=function(){
    Pozivi.ucitajSvoOsoblje();
    Pozivi.ucitajSveSale();
    Pozivi.ucitajZauzeca();
    Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), new Date().getMonth());
    document.getElementById("unos").addEventListener("click",function(){Kalendar.ucitajSaForme();})
    document.getElementById("prethodni").addEventListener("click",function(){Kalendar.prethodni();})
    document.getElementById("sljedeci").addEventListener("click",function(){Kalendar.sljedeci();})
    
    var classname = document.getElementsByClassName("dani"); // uzimamo sve dane
   
    for (var i = 0; i < classname.length; i++) { 
        classname[i].addEventListener("click", klikNaCeliju, false);
    }

}

function dajSemestar(mjesec) {
    if(mjesec == "Oktobar" || mjesec == "Novembar" || mjesec == "Decembar" || mjesec == "Januar")
        return "zimski";

    else if(mjesec == "Februar" || mjesec == "Mart" || mjesec == "April" || mjesec == "Maj")
        return ljetni;

    return "nijedan";
}




var klikNaCeliju = function() {


    var klaseCelije = this.getAttribute("class");
    var zelimRezervaciju = true;

    if(klaseCelije.includes("slobodna")) { // samo ako je slobodna prikazuje se potvrda o rezervaciji
        zelimRezervaciju = confirm("Zelite li rezervisati ovu salu?");
    }

    if(zelimRezervaciju) {

            var periodicna = document.getElementById('periodicna').checked; // da li je periodicna ili vanredna rezervacija

            var nazivSale = document.getElementById('sale');
            nazivSale = nazivSale.options[nazivSale.selectedIndex].text;
            
            var predavac = document.getElementById('osoblje');
            predavac = predavac.options[predavac.selectedIndex].text;

            var pocetak = document.getElementById('pocetak').value;
            var kraj = document.getElementById('kraj').value;
            var dan = parseInt(this.innerHTML);
            var mjesec = document.getElementById("mojKalendar").caption.innerText; // naziv mjeseca (npr. "Januar")
            
            var semestar = dajSemestar(mjesec); // ljetni, zimski ili nijedan
            
            var mjesecBroj = Kalendar.dajRedniBrojMjeseca(mjesec); // "Januar" -> 1

            var danString = dan.toString();
            if(danString.length == 1)
                danString = "0" + danString;

            var mjesecString = mjesecBroj.toString();
            if(mjesecString.length == 1)
                mjesecString = "0" + mjesecString;
            
            


            var datumVanredna = danString+ "." + mjesecString + "." + trenutnaGodina.toString();
            var sveOk = Kalendar.validiraj(nazivSale, pocetak, kraj) && mjesecBroj != 13 && nazivSale != "-" && predavac != "-";

            let prviDan = Kalendar.dajPrviDanMjeseca();
            
            if(sveOk) {
                var rezervacija;
                if(periodicna && semestar!="nijedan") {
                    rezervacija = {
                        "dan": (dan%7-1+prviDan)%7, // treba nam redni broj dana u intervalu [0,6]
                        "semestar": semestar,
                        "pocetak": pocetak,
                        "kraj": kraj,
                        "naziv": nazivSale,
                        "predavac": predavac // Neko Nekic (profesor)
                    }
                }
                else {
                    rezervacija = {
                        "datum": datumVanredna,
                        "pocetak": pocetak,
                        "kraj": kraj,
                        "naziv": nazivSale,
                        "predavac": predavac // Neko Nekic (profesor)
                    }
                }
            Pozivi.rezervisiSalu(rezervacija);
            }
            else {
                alert("Niste unijeli ispravne podatke!")
            }
    }


};

