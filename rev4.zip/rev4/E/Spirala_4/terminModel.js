// ******************************TERMIN****************************************************************
const Sequelize = require("sequelize");

//const db = require('./db.js')


module.exports = function(sequelize, DataTypes) {

    const Termin = sequelize.define('Termin', {
        id:{
            type: Sequelize.INTEGER,
            allowNull: false,
            primaryKey: true
        },
        redovni:{
            type: Sequelize.BOOLEAN
        },
        dan:{
            type: Sequelize.INTEGER
        },
        datum:{
            type: Sequelize.STRING
        },
        semestar:{
            type: Sequelize.STRING // izmjena u odnosu na postavku spirale (gdje pise da treba INTEGER) jer se u ovu kolonu unosi string "zimski"
        },
        pocetak: {
            type: Sequelize.TIME
        },
        kraj: {
            type: Sequelize.TIME
        }

    },
    {
        freezeTableName: true 
    });
    return Termin;

};
//module.exports = Termin;



