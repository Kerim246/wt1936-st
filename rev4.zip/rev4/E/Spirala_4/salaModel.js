// ******************************SALA****************************************************************
const Sequelize = require("sequelize");

module.exports = function(sequelize, DataTypes) {

    const Sala = sequelize.define('Sala', {
        id:{
            type: Sequelize.INTEGER,
            allowNull: false,
            primaryKey: true
        },
        naziv:{
            type: Sequelize.STRING
        }

    },
    {
        freezeTableName: true 
    });

    return Sala;

};
//module.exports = Sala;

