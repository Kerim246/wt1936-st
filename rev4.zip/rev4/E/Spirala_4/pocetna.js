/*include('../pozivi.js');

window.onload=function(){
   console.log('file pocetna.js');
   
}
*/