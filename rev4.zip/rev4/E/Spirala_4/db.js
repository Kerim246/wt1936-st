const Sequelize = require("sequelize");

// definisanje konekcije
const sequelize = new Sequelize("DBWT19","root","root",{host:"localhost",dialect:"mysql",logging:false});
const db={};

db.Sequelize = Sequelize;  
db.sequelize = sequelize;

//import modela
db.osoblje = sequelize.import(__dirname+'/osobljeModel.js');
db.sala = sequelize.import(__dirname+'/salaModel.js');
db.termin = sequelize.import(__dirname+'/terminModel.js');
db.rezervacija = sequelize.import(__dirname+'/rezervacijaModel.js');



//relacije 1-n
db.osoblje.hasMany(db.rezervacija,{
    foreignKey: {
      name: 'osoba'
    }
});
db.sala.hasMany(db.rezervacija,{
    foreignKey: {
      name: 'sala'
    }
});



// relacije 1-1
db.osoblje.hasOne(db.sala,{
    foreignKey: {
      name: 'zaduzenaOsoba'
    }
}); 
db.termin.hasOne(db.rezervacija,{
    foreignKey: {
      name: 'termin'
    }
});
    

module.exports = db; // omogucavamo pristup bazi db iz drugih file-ova
