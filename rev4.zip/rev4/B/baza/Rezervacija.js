const defineRezervacija = (sequelize, Sequelize) => {
  const Rezervacija = sequelize.define("Rezervacija");
  return Rezervacija;
};

exports.Rezervacija = defineRezervacija;
