const defineTermin = (sequelize, Sequelize) => {
  return sequelize.define("Termin", {
    redovni: {
      type: Sequelize.BOOLEAN,
      field: "redovni"
    },
    dan: {
      type: Sequelize.INTEGER,
      field: "dan"
    },
    datum: {
      type: Sequelize.STRING,
      field: "datum"
    },
    semestar: {
      type: Sequelize.STRING,
      field: "semestar"
    },
    pocetak: {
      type: Sequelize.TIME,
      field: "pocetak"
    },
    kraj: {
      type: Sequelize.TIME,
      field: "kraj"
    }
  });
};
exports.Termin = defineTermin;
