const defineOsoblje = (sequelize, Sequelize) => {
  const Osoblje = sequelize.define("Osoblje", {
    ime: {
      type: Sequelize.STRING,
      validate: {
        is: ["[a-z]", "i"]
      },
      field: "ime"
    },
    prezime: {
      type: Sequelize.STRING,
      validate: {
        is: ["[a-z]", "i"]
      },
      field: "prezime"
    },
    uloga: {
      type: Sequelize.STRING,
      validate: {
        is: ["[a-z]", "i"]
      },
      field: "uloga"
    }
  });
  return Osoblje;
};

exports.Osoblje = defineOsoblje;
