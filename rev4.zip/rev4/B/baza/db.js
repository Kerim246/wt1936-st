const { Rezervacija } = require("./Rezervacija");
const { Sala } = require("./Sala");
const { Termin } = require("./Termin");
const Sequelize = require("sequelize");
const { Osoblje } = require("./Osoblje");

const sequelize = new Sequelize("DBWT19", "root", "root", {
  host: "localhost",
  dialect: "mysql",
  dialectOptions: {
    socketPath: "/tmp/mysql.sock"
  }
});

const osoblje = Osoblje(sequelize, Sequelize);
const rezervacije = Rezervacija(sequelize, Sequelize);
const sale = Sala(sequelize, Sequelize);
const termin = Termin(sequelize, Sequelize);

// asocijacije:
osoblje.hasMany(rezervacije, { foreignKey: "osoba" });
rezervacije.belongsTo(osoblje, { foreignKey: "osoba" });
termin.hasOne(rezervacije, { foreignKey: "termin" });
rezervacije.belongsTo(termin, { foreignKey: "termin" });
sale.hasMany(rezervacije, { foreignKey: "sala" });
rezervacije.belongsTo(sale, { foreignKey: "sala" });
osoblje.hasOne(sale, { foreignKey: "zaduzenaOsoba" });
sale.belongsTo(osoblje, { foreignKey: "zaduzenaOsoba" });

exports.models = {
  sequelize,
  osoblje,
  rezervacije,
  sale,
  termin
};
