const defineSala = (sequelize, Sequelize) => {
  const Sala = sequelize.define("Sala", {
    naziv: {
      type: Sequelize.STRING,
      field: "naziv"
    }
  });
  return Sala;
};

exports.Sala = defineSala;
