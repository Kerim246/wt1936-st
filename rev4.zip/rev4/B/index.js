const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const { models } = require("./baza/db");

const { sequelize, osoblje, rezervacije, sale, termin } = models;
const app = express();
const port = 3000;

const BROJ_SLIKA_PO_STRANICI = 3;

const SEMESTRI = {
  zimski: [10, 11, 12, 1],
  ljetni: [2, 3, 4, 5, 6]
};

dajSemestar = mjesec => {
  const { zimski, ljetni } = SEMESTRI;
  let jeLjetni = false;
  zimski.forEach(element => {
    if (element === mjesec) {
      jeLjetni = false;
    }
  });
  ljetni.forEach(element => {
    if (element === mjesec) {
      jeLjetni = true;
    }
  });
  return jeLjetni ? "ljetni" : "zimski";
};

function seVremenaPoklapaju(vrijemeZauzeca, odabranoVrijeme) {
  let vrijemeZauzecaStart = new Date("2019-12-25T" + vrijemeZauzeca[0]);
  let vrijemeZauzecaEnd = new Date("2019-12-25T" + vrijemeZauzeca[1]);
  let odabranoVrijemeStart = new Date("2019-12-25T" + odabranoVrijeme[0]);
  let odabranoVrijemeEnd = new Date("2019-12-25T" + odabranoVrijeme[1]);
  return (
    vrijemeZauzecaStart <= odabranoVrijemeEnd &&
    odabranoVrijemeStart <= vrijemeZauzecaEnd
  );
}

function dajDanUSedmici({ dan, mjesec, godina }) {
  const datum = new Date(godina, mjesec - 1, dan, 12, 0);
  let danUSedmici = datum.getDay();
  return danUSedmici;
}

dajIzBaze = async () => {
  const svaZauzeca = await rezervacije.findAll({
    include: [
      { model: models.termin },
      { model: models.sale },
      { model: models.osoblje }
    ]
  });
  const periodicna = [];
  const vanredna = [];
  svaZauzeca.forEach(zauzece => {
    const { dan, semestar, redovni, pocetak, kraj, datum } = zauzece.Termin;
    const { naziv } = zauzece.Sala;
    const { ime, prezime } = zauzece.Osoblje;
    const zauzeceFull = {
      dan,
      semestar,
      pocetak,
      kraj,
      datum,
      naziv,
      ime,
      prezime
    };
    if (redovni == 1) periodicna.push(zauzeceFull);
    else vanredna.push(zauzeceFull);
  });
  return [periodicna, vanredna];
};

zauzecePostoji = async (
  zauzece,
  semestarNovogZauzeca,
  danUSedmici,
  datumNovogZauzeca,
  callback,
  res,
  req
) => {
  const [periodicna, vanredna] = await dajIzBaze();
  for (let i = 0; i < periodicna.length; i++) {
    const element = periodicna[i];
    const { dan, semestar, pocetak, kraj, naziv } = element;
    if (
      dan == danUSedmici &&
      semestar == semestarNovogZauzeca &&
      naziv == zauzece.sala &&
      seVremenaPoklapaju([zauzece.pocetak, zauzece.kraj], [pocetak, kraj])
    ) {
      await callback(
        true,
        {
          ...zauzece,
          danUSedmici,
          semestarNovogZauzeca,
          datumNovogZauzeca,
          ime: element.ime,
          prezime: element.prezime
        },
        res,
        req
      );
      return;
    }
  }

  for (let i = 0; i < vanredna.length; i++) {
    const element = vanredna[i];
    const { datum, pocetak, kraj, naziv } = element;
    if (
      datum == datumNovogZauzeca &&
      naziv == zauzece.sala &&
      seVremenaPoklapaju([zauzece.pocetak, zauzece.kraj], [pocetak, kraj])
    ) {
      await callback(
        true,
        {
          ...zauzece,
          danUSedmici,
          semestarNovogZauzeca,
          datumNovogZauzeca,
          ime: element.ime,
          prezime: element.prezime
        },
        res,
        req
      );
      return;
    }
  }
  await callback(
    false,
    {
      ...zauzece,
      danUSedmici,
      semestarNovogZauzeca,
      datumNovogZauzeca,
      ime: zauzece.ime,
      prezime: zauzece.prezime
    },
    res,
    req
  );
};

function generisiPeriodicno({
  danUSedmici,
  semestarNovogZauzeca,
  pocetak,
  kraj,
  sala,
  predavac
}) {
  return {
    dan: danUSedmici,
    semestar: semestarNovogZauzeca,
    pocetak,
    kraj,
    datum: null,
    redovni: true
  };
}

function generisiVanredno({
  datumNovogZauzeca,
  pocetak,
  kraj,
  sala,
  predavac
}) {
  return {
    datum: datumNovogZauzeca,
    pocetak,
    kraj,
    dan: null,
    semestar: null,
    redovni: false
  };
}

async function callback(postoji, request, res, req) {
  const {
    sala,
    dan,
    mjesec,
    godina,
    pocetak,
    kraj,
    jePeriodicna,
    danUSedmici,
    semestarNovogZauzeca,
    datumNovogZauzeca,
    ime,
    prezime
  } = request;
  if (postoji) {
    const error = `Salu zauzela osoba: ${ime +
      " " +
      prezime}. Nije moguće rezervisati salu ${sala} za navedeni datum ${dan}/${mjesec}/${godina} i termin od ${pocetak} do ${kraj}!`;
    console.log(error);
    res.status(400);
    res.send(error);
  } else {
    try {
      const osoba =
        (await osoblje.findOne({ where: { prezime: prezime, ime: ime } })) ||
        (await osoblje.create({
          ime: ime,
          prezime: prezime,
          uloga: "asistent"
        }));
      const terminn = await termin.create(
        jePeriodicna ? generisiPeriodicno(request) : generisiVanredno(request)
      );
      const salaDb = await sale.create({ naziv: sala });

      const rezervacija = await rezervacije.create();
      await rezervacija.setTermin(terminn);
      await rezervacija.setSala(salaDb);
      await rezervacija.setOsoblje(osoba);
      const [periodicna, vanredna] = await dajIzBaze();
      res.send({ periodicna: periodicna, vanredna: vanredna });
    } catch (err) {
      throw err;
    }
  }
}

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.get("/", (req, res) => {
  res.sendFile("./public/pocetna.html", { root: __dirname });
});

app.get("/zauzeca", async (req, res) => {
  const [periodicna, vanredna] = await dajIzBaze();
  res.send({ periodicna: periodicna, vanredna: vanredna });
});

app.post("/zauzeca", async (req, res) => {
  const request = req.body;
  request.mjesec++;
  const semestarNovogZauzeca = dajSemestar(request.mjesec);
  const danUSedmici = dajDanUSedmici(request);
  const datumNovogZauzeca = `${request.dan}.${request.mjesec}.${request.godina}`;
  await zauzecePostoji(
    request,
    semestarNovogZauzeca,
    danUSedmici,
    datumNovogZauzeca,
    callback,
    res,
    req
  );
});

app.get("/slike", (req, res) => {
  const { stranica } = req.query;
  fs.readFile("./slike.json", (err, data) => {
    if (err) throw err;
    const { slike } = JSON.parse(data.toString());
    const indeksPrveSlike = (stranica - 1) * BROJ_SLIKA_PO_STRANICI;
    const indeksZadnjeSlike = indeksPrveSlike + BROJ_SLIKA_PO_STRANICI - 1;
    let slikeRez = [];
    let jePosljednjaStranica = false;
    for (let i = indeksPrveSlike; i <= indeksZadnjeSlike; i++) {
      if (slike[i] == null) jePosljednjaStranica = true;
      slikeRez.push(slike[i]);
    }
    res.send({ slikeRez, jePosljednjaStranica });
  });
});

app.get("/osoblje", async (req, res) => {
  const osoblje = await models.osoblje.findAll();
  res.send(osoblje);
});

sequelize
  .sync({ force: true })
  .then(async res => {
    const osoba1 = await osoblje.create({
      ime: "Neko",
      prezime: "Nekic",
      uloga: "profesor"
    });
    const osoba2 = await osoblje.create({
      ime: "Drugi",
      prezime: "Neko",
      uloga: "asistent"
    });
    const osoba3 = await osoblje.create({
      ime: "Test",
      prezime: "Test",
      uloga: "asistent"
    });

    let sala1 = await sale.create({
      naziv: "1-11"
    });
    sala1.setOsoblje(osoba1);

    let sala2 = await sale.create({
      naziv: "1-15"
    });
    sala2.setOsoblje(osoba2);

    const termin1 = await termin.create({
      redovni: false,
      dan: null,
      datum: "01.01.2020",
      semestar: null,
      pocetak: "12:00",
      kraj: "13:00"
    });
    const termin2 = await termin.create({
      redovni: true,
      dan: 0,
      datum: null,
      semestar: "zimski",
      pocetak: "13:00",
      kraj: "14:00"
    });

    const rezervacija = await rezervacije.create();
    rezervacija.setTermin(termin1);
    rezervacija.setSala(sala1);
    rezervacija.setOsoblje(osoba1);

    const rezervacija2 = await rezervacije.create();
    rezervacija2.setTermin(termin2);
    rezervacija2.setOsoblje(osoba3);
    rezervacija2.setSala(sala1);

    app.listen(port, () => {
      console.log("Server started on port", port);
    });
  })
  .catch(err => {
    console.log(err);
  });
