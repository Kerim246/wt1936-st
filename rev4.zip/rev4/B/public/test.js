let assert = chai.assert;

describe("Kalendar", function() {
  const REDOVI = 6;
  const KOLONE = 7;
  let kalendarRef = null;

  before(() => {
    kalendarRef = document.createElement("div");
    kalendarRef.id = "kalendar";
    document.getElementsByTagName("body")[0].appendChild(kalendarRef);
  });

  beforeEach(() => {
    Kalendar.ucitajPodatke([], []);
  });

  it("Pozivanje obojiZauzeca kada podaci nisu učitani: očekivana vrijednost da se ne oboji niti jedan dan", function() {
    Kalendar.iscrtajKalendar(kalendarRef, 11);
    Kalendar.obojiZauzeca(kalendarRef, 11, "1-01", "12:00", "13:00");

    for (let i = 0; i < REDOVI; i++) {
      const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[i];
      const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
      for (let j = 0; j < KOLONE; j++) {
        const danCelija = daniObj[j];
        if (danCelija.className == "salaKalendar") {
          assert.equal(
            danCelija
              .getElementsByClassName("status")[0]
              .classList.contains("zauzeto"),
            false,
            "Ne smije biti nijedna sala zauzeta"
          );
        }
      }
    }
  });

  it("Pozivanje obojiZauzeca gdje u zauzećima postoje duple vrijednosti za zauzeće istog termina: očekivano je da se dan oboji bez obzira što postoje duple vrijednosti", function() {
    Kalendar.iscrtajKalendar(kalendarRef, 10);
    Kalendar.ucitajPodatke(
      [
        {
          dan: 4,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "13:00",
          naziv: "0-09",
          predavac: "prof"
        }
      ],
      [
        {
          datum: "29.11.2019",
          pocetak: "12:00",
          kraj: "13:00",
          naziv: "0-09",
          predavac: "asistent"
        }
      ]
    );

    Kalendar.obojiZauzeca(kalendarRef, 10, "0-09", "12:00", "13:00");
    Kalendar.obojiZauzeca(kalendarRef, 10, "0-09", "12:00", "13:00");

    //ocekujemo 29.11. obojen (preklapanja)
    for (let i = 0; i < REDOVI; i++) {
      const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[i];
      const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
      for (let j = 0; j < KOLONE; j++) {
        const danCelija = daniObj[j];
        if (danCelija.className == "salaKalendar") {
          const brojSale = danCelija.getElementsByClassName("brojSale")[0]
            .innerHTML;
          const jeZauzeto = danCelija
            .getElementsByClassName("status")[0]
            .classList.contains("zauzeto");
          if (brojSale == 29) {
            assert.equal(jeZauzeto, true, "29.11. mora biti obojen");
          }
        }
      }
    }
  });

  it("Pozivanje obojiZauzece kada u podacima postoji periodično zauzeće za drugi semestar: očekivano je da se ne oboji zauzeće", function() {
    Kalendar.iscrtajKalendar(kalendarRef, 10);
    const danSedmica = 4;
    Kalendar.ucitajPodatke(
      [
        {
          dan: danSedmica,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "13:00",
          naziv: "0-09",
          predavac: "prof"
        }
      ],
      []
    );

    Kalendar.obojiZauzeca(kalendarRef, 2, "0-09", "12:00", "13:00");

    const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[
      danSedmica
    ];
    const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
    for (let j = 0; j < KOLONE; j++) {
      const danCelija = daniObj[j];
      if (danCelija.className == "salaKalendar") {
        const jeZauzeto = danCelija
          .getElementsByClassName("status")[0]
          .classList.contains("zauzeto");
        assert.equal(
          jeZauzeto,
          false,
          "dani 1, 8, 15, 22 i 29 ne smiju biti obojeni"
        );
      }
    }
  });

  it("Pozivanje obojiZauzece kada u podacima postoji zauzeće termina ali u drugom mjesecu: očekivano je da se ne oboji zauzeće", function() {
    Kalendar.iscrtajKalendar(kalendarRef, 10);
    Kalendar.ucitajPodatke(
      [],
      [
        {
          datum: "29.11.2019",
          pocetak: "12:00",
          kraj: "13:00",
          naziv: "0-09",
          predavac: "asistent"
        }
      ]
    );

    Kalendar.obojiZauzeca(kalendarRef, 2, "0-09", "12:00", "13:00");

    const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[
      REDOVI - 2
    ];
    const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
    const danCelija = daniObj[4];
    const jeZauzeto = danCelija
      .getElementsByClassName("status")[0]
      .classList.contains("zauzeto");
    assert.equal(jeZauzeto, false, "29. ne smije biti obojen");
  });

  it("Pozivanje obojiZauzece kada u podacima postoji zauzeće termina ali u drugom mjesecu: očekivano je da se ne oboji zauzeće", function() {
    let arr = [];
    for (let i = 0; i < 7; i++) {
      arr.push({
        dan: i,
        semestar: "zimski",
        pocetak: "12:00",
        kraj: "13:00",
        naziv: "0-09",
        predavac: "prof"
      });
    }

    Kalendar.ucitajPodatke(arr, []);
    Kalendar.iscrtajKalendar(kalendarRef, 10);
    Kalendar.obojiZauzeca(kalendarRef, 10, "0-09", "12:00", "13:00");

    for (let i = 0; i < REDOVI; i++) {
      const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[i];
      const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
      for (let j = 0; j < KOLONE; j++) {
        const danCelija = daniObj[j];
        if (danCelija.className == "salaKalendar") {
          assert.equal(
            danCelija
              .getElementsByClassName("status")[0]
              .classList.contains("zauzeto"),
            true,
            "Moraju sve sale biti zauzete"
          );
        }
      }
    }
  });
  it("Dva puta uzastopno pozivanje obojiZauzece: očekivano je da boja zauzeća ostane ista", function() {
    Kalendar.iscrtajKalendar(kalendarRef, 10);
    Kalendar.ucitajPodatke(
      [],
      [
        {
          datum: "29.11.2019",
          pocetak: "12:00",
          kraj: "13:00",
          naziv: "0-09",
          predavac: "asistent"
        }
      ]
    );

    Kalendar.obojiZauzeca(kalendarRef, 10, "0-09", "12:00", "13:00");
    Kalendar.obojiZauzeca(kalendarRef, 10, "0-09", "12:00", "13:00");

    const elem = document.querySelector(".kalendarDan .status.zauzeto");
    const style = getComputedStyle(elem);
    assert.equal(
      style.backgroundColor,
      "rgb(255, 69, 0)",
      "Boja mora biti orangered tj. rgb(255, 69, 0)"
    );
  });
  it("Pozivanje ucitajPodatke, obojiZauzeca, ucitajPodatke - drugi podaci, obojiZauzeca: očekivano da se zauzeća iz prvih podataka ne ostanu obojena, tj. primjenjuju se samo posljednje učitani podaci", function() {
    Kalendar.iscrtajKalendar(kalendarRef, 10);
    Kalendar.ucitajPodatke(
      [],
      [
        {
          datum: "29.11.2019",
          pocetak: "12:00",
          kraj: "13:00",
          naziv: "0-09",
          predavac: "asistent"
        }
      ]
    );
    Kalendar.obojiZauzeca(kalendarRef, 10, "0-09", "12:00", "13:00");
    Kalendar.ucitajPodatke(
      [],
      [
        {
          datum: "30.11.2019",
          pocetak: "12:00",
          kraj: "13:00",
          naziv: "0-09",
          predavac: "asistent"
        }
      ]
    );
    Kalendar.obojiZauzeca(kalendarRef, 10, "0-09", "12:00", "13:00");

    const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[
      REDOVI - 2
    ];
    const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
    let danCelija = daniObj[4];
    let jeZauzeto = danCelija
      .getElementsByClassName("status")[0]
      .classList.contains("zauzeto");
    assert.equal(jeZauzeto, false, "29. ne smije biti obojen");
    danCelija = daniObj[5];
    jeZauzeto = danCelija
      .getElementsByClassName("status")[0]
      .classList.contains("zauzeto");
    assert.equal(jeZauzeto, true, "30. mora biti obojen");
  });

  //testira granicni slucaj
  it("(1) Test po izboru: odabrano vrijeme se preklapa sa vremenom u podacima, tj. kraj u podacima jednak pocetku u obojiZauzeca: ocekivano da datum ne bude zauzet", function() {
    Kalendar.iscrtajKalendar(kalendarRef, 10);
    Kalendar.ucitajPodatke(
      [],
      [
        {
          datum: "29.11.2019",
          pocetak: "12:00",
          kraj: "13:00",
          naziv: "0-09",
          predavac: "asistent"
        }
      ]
    );
    Kalendar.obojiZauzeca(kalendarRef, 10, "0-09", "13:00", "14:00");

    const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[
      REDOVI - 2
    ];
    const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
    let danCelija = daniObj[4];
    let jeZauzeto = danCelija
      .getElementsByClassName("status")[0]
      .classList.contains("zauzeto");
    assert.equal(jeZauzeto, false, "29. ne smije biti obojen");
  });

  it("(2) Test po izboru: sala u oboji zauzeca jednaka sali u podacima: ocekivano da vremena za tu salu budu obojena, a za ostale sale u podacima da nisu", function() {
    Kalendar.iscrtajKalendar(kalendarRef, 10);
    Kalendar.ucitajPodatke(
      [],
      [
        {
          datum: "29.11.2019",
          pocetak: "12:00",
          kraj: "13:00",
          naziv: "0-09",
          predavac: "asistent"
        },
        {
          datum: "30.11.2019",
          pocetak: "12:00",
          kraj: "13:00",
          naziv: "0-01",
          predavac: "asistent"
        }
      ]
    );
    Kalendar.obojiZauzeca(kalendarRef, 10, "0-09", "12:00", "13:00");

    //ocekivano da 29. bude obojen, a 30. ne bude
    const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[
      REDOVI - 2
    ];
    const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
    let danCelija = daniObj[4];
    let jeZauzeto = danCelija
      .getElementsByClassName("status")[0]
      .classList.contains("zauzeto");
    assert.equal(jeZauzeto, true, "29. mora biti obojen");

    danCelija = daniObj[5];
    jeZauzeto = danCelija
      .getElementsByClassName("status")[0]
      .classList.contains("zauzeto");
    assert.equal(jeZauzeto, false, "30. ne smije biti obojen");
  });

  after(() => {
    kalendarRef.innerHTML = "";
  });
});

describe("Kalendar2", function() {
  const REDOVI = 6;
  const KOLONE = 7;
  let kalendarRef = null;

  before(() => {
    kalendarRef = document.createElement("div");
    kalendarRef.id = "kalendar";
    document.getElementsByTagName("body")[0].appendChild(kalendarRef);
  });

  beforeEach(() => {
    Kalendar.ucitajPodatke([], []);
  });

  it("Pozivanje iscrtajKalendar za mjesec sa 30 dana: očekivano je da se prikaže 30 dana", () => {
    Kalendar.iscrtajKalendar(kalendarRef, 10);
    let brojDana = 0;
    for (let i = 0; i < REDOVI; i++) {
      const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[i];
      const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
      for (let j = 0; j < KOLONE; j++) {
        const danCelija = daniObj[j];
        if (danCelija.className == "salaKalendar") brojDana++;
      }
    }
    assert.equal(brojDana, 30, "Broj dana u novembru mora biti 30");
  });

  it("Pozivanje iscrtajKalendar za mjesec sa 31 dana: očekivano je da se prikaže 31 dan", () => {
    Kalendar.iscrtajKalendar(kalendarRef, 11);
    let brojDana = 0;
    for (let i = 0; i < REDOVI; i++) {
      const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[i];
      const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
      for (let j = 0; j < KOLONE; j++) {
        const danCelija = daniObj[j];
        if (danCelija.className == "salaKalendar") brojDana++;
      }
    }
    assert.equal(brojDana, 31, "Broj dana u decembru mora biti 31");
  });

  it("Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 1. dan u petak", () => {
    Kalendar.iscrtajKalendar(kalendarRef, 10);
    //prvi red
    const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[0];
    const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
    //kolona koja predstavlja petak:
    let danCelija = daniObj[4];
    console.log(danCelija);
    const broj = danCelija.getElementsByClassName("brojSale")[0].innerHTML;
    assert.equal(broj, 1, "petak mora biti prvi dan u novembru");
  });

  it("Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 30. dan u subotu", () => {
    Kalendar.iscrtajKalendar(kalendarRef, 10);
    //zadnji red novembra u kalendaru:
    const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[
      REDOVI - 2
    ];
    const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
    //kolona koja predstavlja subotu:
    let danCelija = daniObj[5];
    console.log(danCelija);
    const broj = danCelija.getElementsByClassName("brojSale")[0].innerHTML;
    assert.equal(broj, 30, "subota mora biti zadnji dan u novembru");
  });

  it("Pozivanje iscrtajKalendar za januar: očekivano je da brojevi dana idu od 1 do 31 počevši od utorka", () => {
    Kalendar.iscrtajKalendar(kalendarRef, 0);
    let brojDana = 0;
    for (let i = 0; i < REDOVI; i++) {
      const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[i];
      const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
      for (let j = 0; j < KOLONE; j++) {
        const danCelija = daniObj[j];
        if (danCelija.className == "salaKalendar") {
          brojDana++;
          const broj = danCelija.getElementsByClassName("brojSale")[0]
            .innerHTML;
          assert.equal(broj, brojDana, `Trenutni dan mora biti ${brojDana}`);
        }
      }
    }
  });

  it("(1) Test po izboru: ocekivano da nijedan mjesec nema dan veci od 31", function() {
    for (let k = 0; k < 11; k++) {
      Kalendar.iscrtajKalendar(kalendarRef, k);
      for (let i = 0; i < REDOVI; i++) {
        const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[
          i
        ];
        const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
        for (let j = 0; j < KOLONE; j++) {
          const danCelija = daniObj[j];
          if (danCelija.className == "salaKalendar") {
            const broj = danCelija.getElementsByClassName("brojSale")[0]
              .innerHTML;
            const jeVeci = broj > 31;
            assert.equal(jeVeci, false, "Najveci broj mora biti 31");
          }
        }
      }
    }
  });

  it("(2) Test po izboru: ocekivano da svaka celija svakog mjeseca bude zelene boje - oznacena kao slobodna od samog pocetka", function() {
    for (let k = 0; k < 11; k++) {
      Kalendar.iscrtajKalendar(kalendarRef, k);
      for (let i = 0; i < REDOVI; i++) {
        const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[
          i
        ];
        const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
        for (let j = 0; j < KOLONE; j++) {
          const danCelija = daniObj[j];
          if (danCelija.className == "salaKalendar") {
            const jeSlobodna = danCelija.getElementsByClassName("slobodno")[0]
              .innerHTML;
            assert.isNotNull(jeSlobodna, "Svaka celija mora biti slobodna");
          }
        }
      }
    }
  });

  after(() => {
    kalendarRef.innerHTML = "";
  });
});
