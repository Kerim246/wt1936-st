let Kalendar = (function() {
  periodicna = [];
  vanredna = [];

  const SEMESTRI = {
    zimski: [10, 11, 12, 1],
    ljetni: [2, 3, 4, 5, 6]
  };
  const REDOVI = 6;
  const KOLONE = 7;
  const VANREDNI = "vanredni";
  const PERIODICNI = "periodicni";
  const GODINA = 2020;
  const MJESECI = {
    1: {
      ime: "Januar",
      dani: 31
    },
    2: {
      ime: "Februar",
      dani: 28
    },
    3: {
      ime: "Mart",
      dani: 31
    },
    4: {
      ime: "April",
      dani: 30
    },
    5: {
      ime: "Maj",
      dani: 31
    },
    6: {
      ime: "Juni",
      dani: 30
    },
    7: {
      ime: "Juli",
      dani: 31
    },
    8: {
      ime: "August",
      dani: 31
    },
    9: {
      ime: "Septembar",
      dani: 30
    },
    10: {
      ime: "Oktobar",
      dani: 31
    },
    11: {
      ime: "Novembar",
      dani: 30
    },
    12: {
      ime: "Decembar",
      dani: 31
    }
  };

  let obojeneCelije = [];

  function dajDanePrvaSedmica(mjesec) {
    let niz = [];
    for (let j = 0; j < 7; j++) {
      var date = new Date(GODINA, mjesec - 1, j);
      niz.push(date.getDay());
      if (date.getDay() == 6) break;
    }
    return niz;
  }

  function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj) {
    obrisiBoje(obojeneCelije || []);
    mjesec++;
    const [periodicni, vanredni] = izvuciPodatkeZaNavedeniMjesec(
      this.periodicna || [],
      this.vanredna || [],
      mjesec,
      sala,
      pocetak,
      kraj
    );
    if (vanredni) oboji(kalendarRef, vanredni, VANREDNI);
    if (periodicni) oboji(kalendarRef, periodicni, PERIODICNI);
  }
  function ucitajPodatkeImpl(periodicna, vanredna) {
    this.periodicna = periodicna;
    this.vanredna = vanredna;
  }
  function iscrtajKalendarImpl(kalendarRef, mjesec) {
    mjesec++;
    kalendarRef.innerHTML = "";
    const niz = dajDanePrvaSedmica(mjesec);
    let danBrojac = 0;
    let dodajCeliju = false;

    azurirajMjesec(kalendarRef, mjesec);

    const daniContainer = document.createElement("div");
    daniContainer.classList.add("daniContainer");
    kreirajDaneHeader(daniContainer);

    const kalendarPolja = document.createElement("div");
    kalendarPolja.classList.add("kalendarPolja");

    for (let i = 0; i < REDOVI; i++) {
      const kalendarDan = kalendarRef.appendChild(
        document.createElement("div")
      );
      kalendarDan.classList.add("kalendarDan");
      if (i == 0) kalendarDan.classList.add("prvi");
      else kalendarDan.classList.add("w-600");
      for (let j = 0; j < KOLONE; j++) {
        const div = document.createElement("div");
        if (i == 0 && niz.includes(j)) dodajCeliju = true;
        if (danBrojac == MJESECI[mjesec].dani) dodajCeliju = false;
        if (dodajCeliju) danBrojac = htmlKreirajCeliju(div, danBrojac);
        kalendarDan.appendChild(div);
      }
      kalendarPolja.appendChild(kalendarDan);
    }
    kalendarRef.appendChild(daniContainer);
    kalendarRef.appendChild(kalendarPolja);

    const celija = document.querySelectorAll(".salaKalendar");
    for (let i = 0; i < celija.length; i++) {
      const dan = i + 1;
      celija[i].addEventListener("click", function() {
        Pozivi.posaljiZauzece(
          dan,
          mjesec - 1,
          2019,
          document.querySelector("input[name=pocetak]").value,
          document.querySelector("input[name=kraj]").value,
          document.querySelector("input[name=periodicna]").checked,
          document.getElementById("opcijaSale").value,
          document.getElementById("osoblje").value
        );
      });
    }
  }

  function azurirajMjesec(kalendarRef, mjesec) {
    const kMjesec = document.createElement("p");
    kMjesec.id = "mjesec";
    kMjesec.innerText = "Novembar";
    kalendarRef.appendChild(kMjesec);

    document.getElementById("mjesec").innerHTML = MJESECI[mjesec].ime;
  }

  function kreirajDaneHeader(daniContainer) {
    const kalendarDani = document.createElement("div");
    kalendarDani.classList.add("kalendarDani");

    const dani = ["PON", "UTO", "SRI", "CET", "PET", "SUB", "NED"];
    dani.forEach(element => {
      const dan = document.createElement("div");
      dan.innerText = element;
      kalendarDani.appendChild(dan);
    });
    daniContainer.appendChild(kalendarDani);
  }

  function htmlKreirajCeliju(div, danBrojac) {
    div.classList.add("salaKalendar");
    const brojSale = document.createElement("div");
    const status = document.createElement("div");
    brojSale.classList.add("brojSale");
    status.classList.add("status", "slobodno");
    brojSale.textContent = ++danBrojac;
    div.appendChild(brojSale);
    div.appendChild(document.createElement("hr"));
    div.appendChild(status);
    return danBrojac;
  }

  function izvuciPodatkeZaNavedeniMjesec(
    periodicna,
    vanredna,
    mjesec,
    sala,
    pocetak,
    kraj
  ) {
    let periodicni = izvuciPeriodicne(periodicna, mjesec, sala, pocetak, kraj);
    let vanredni = izvuciVanredne(vanredna, mjesec, sala, pocetak, kraj);
    return [periodicni, vanredni];
  }

  function izvuciPeriodicne(periodicna, mjesec, sala, pocetakParam, krajParam) {
    let periodicni = [];
    periodicna.forEach(element => {
      const { semestar, pocetak, kraj, naziv } = element;
      if (
        SEMESTRI[semestar].includes(mjesec) &&
        seVremenaPoklapaju([pocetak, kraj], [pocetakParam, krajParam]) &&
        sala == naziv
      )
        periodicni.push(element);
    });
    return periodicni;
  }

  function izvuciVanredne(vanredna, mjesec, sala, pocetakParam, krajParam) {
    let vanredni = [];
    vanredna.forEach(element => {
      const { datum, pocetak, kraj, naziv } = element;
      const [puniDatum, dan, elMjesec, godina] = datum.match(
        /(.*)\.(.*)\.(.*)/
      );
      if (
        mjesec == elMjesec &&
        sala == naziv &&
        seVremenaPoklapaju([pocetak, kraj], [pocetakParam, krajParam])
      ) {
        const izmjenjeniElement = { ...element };
        izmjenjeniElement.datum = {
          puniDatum,
          dan,
          mjesec,
          godina
        };
        vanredni.push(izmjenjeniElement);
      }
    });
    return vanredni;
  }

  // Takodjer pokriva granicne slucajeve
  // npr da je potrebno rezervisati salu u 12:00, a u 12:00 zavrsava neki termin isti dan
  // tada je obojeno zeleno
  function seVremenaPoklapaju(vrijemeZauzeca, odabranoVrijeme) {
    let vrijemeZauzecaStart = new Date("2019-11-22T" + vrijemeZauzeca[0]);
    let vrijemeZauzecaEnd = new Date("2019-11-22T" + vrijemeZauzeca[1]);
    let odabranoVrijemeStart = new Date("2019-11-22T" + odabranoVrijeme[0]);
    let odabranoVrijemeEnd = new Date("2019-11-22T" + odabranoVrijeme[1]);
    return (
      vrijemeZauzecaStart <= odabranoVrijemeEnd &&
      odabranoVrijemeStart <= vrijemeZauzecaEnd
    );
  }

  function oboji(kalendarRef, niz, tipPodataka) {
    niz.forEach(element => {
      for (let i = 0; i < REDOVI; i++) {
        const kalendarDan = kalendarRef.getElementsByClassName("kalendarDan")[
          i
        ];
        const daniObj = kalendarDan.querySelectorAll(".kalendarDan>div");
        for (let j = 0; j < KOLONE; j++) {
          const danCelija = daniObj[j];
          if (danCelija.className == "salaKalendar") {
            if (tipPodataka == VANREDNI) {
              obojiVanredna(element.datum, danCelija);
            } else if (tipPodataka == PERIODICNI) {
              obojiPeriodicna(element, j, danCelija);
            }
          }
        }
      }
    });
  }

  function obojiVanredna({ dan }, danCelija) {
    dan = parseInt(dan);
    const brojSale = danCelija.getElementsByClassName("brojSale")[0].innerText;
    if (brojSale == dan) obojiCeliju(danCelija);
  }

  function obojiPeriodicna({ dan }, itKolona, danCelija) {
    if (itKolona == dan) obojiCeliju(danCelija);
  }

  function obojiCeliju(celija) {
    celija.getElementsByClassName("status")[0].classList.add("zauzeto");
    obojeneCelije.push(celija);
  }

  function obrisiBoje(obojeneCelije) {
    obojeneCelije.forEach(element => {
      element.getElementsByClassName("status")[0].classList.remove("zauzeto");
    });
    obojeneCelije = [];
  }

  return {
    obojiZauzeca: obojiZauzecaImpl,
    ucitajPodatke: ucitajPodatkeImpl,
    iscrtajKalendar: iscrtajKalendarImpl
  };
})();
