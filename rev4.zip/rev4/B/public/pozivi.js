let Pozivi = (function() {
  function dajZauzeca(mjesec) {
    const ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        const { periodicna, vanredna } = JSON.parse(ajax.responseText);
        Kalendar.ucitajPodatke(periodicna, vanredna);
        Kalendar.obojiZauzeca(
          document.getElementById("kalendar"),
          mjesec,
          KalendarLink.sala,
          KalendarLink.pocetak,
          KalendarLink.kraj
        );
      }
      if (ajax.readyState == 4 && ajax.status == 404) {
        console.log(ajax.responseText);
      }
    };
    ajax.open("GET", "http://localhost:3000/zauzeca", true);
    ajax.send();
  }

  function dajOsoblje() {
    const ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        const osoblje = JSON.parse(ajax.responseText);
        selectOsoblje = document.getElementById("osoblje");
        osoblje.forEach(osoba => {
          const option = document.createElement("option");
          option.text = osoba.ime + " " + osoba.prezime;
          selectOsoblje.add(option);
        });
      }
      if (ajax.readyState == 4 && ajax.status == 404) {
        console.log(ajax.responseText);
      }
    };
    ajax.open("GET", "http://localhost:3000/osoblje", true);
    ajax.send();
  }

  function posaljiZauzece(
    dan,
    mjesec,
    godina,
    pocetak,
    kraj,
    jePeriodicna,
    sala,
    osoba
  ) {
    const [ime, prezime] = osoba.split(" ");
    const zahtjev = {
      dan,
      mjesec,
      godina,
      pocetak,
      kraj,
      jePeriodicna,
      sala,
      ime,
      prezime
    };
    const ajax = new XMLHttpRequest();

    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        const { periodicna, vanredna } = JSON.parse(ajax.responseText);
        Kalendar.ucitajPodatke(periodicna, vanredna);
        Kalendar.obojiZauzeca(
          document.getElementById("kalendar"),
          mjesec,
          sala,
          pocetak,
          kraj
        );
      } else if (ajax.readyState == 4) {
        alert(ajax.responseText);
        console.log(ajax.responseText);
      }
    };
    if (
      confirm(
        `Jeste li sigurni da zelite rezervisati ${sala} za datum ${dan}/${mjesec +
          1}/${godina + 1} u ${pocetak} do ${kraj}?`
      )
    ) {
      ajax.open("POST", "http://localhost:3000/zauzeca", true);
      ajax.setRequestHeader("Content-Type", "application/json");
      ajax.send(JSON.stringify(zahtjev));
    }
  }

  function dajSlike(stranica) {
    const ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        const { slikeRez, jePosljednjaStranica } = JSON.parse(
          ajax.responseText
        );
        Galerija.ucitajSlike(slikeRez, jePosljednjaStranica);
        Galerija.ispisiSlike();
      }
      if (ajax.readyState == 4 && ajax.status == 404) {
        console.log(ajax.responseText);
      }
    };
    ajax.open("GET", "http://localhost:3000/slike?stranica=" + stranica, true);
    ajax.send();
  }

  return {
    dajZauzeca,
    posaljiZauzece,
    dajSlike,
    dajOsoblje
  };
})();
