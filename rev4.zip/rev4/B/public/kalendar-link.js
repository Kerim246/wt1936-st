let KalendarLink = (function() {
  let pocetak = "00:00";
  let kraj = "00:00";
  let sala = "0-01";
  let mjesec = 0;

  if (mjesec == 11) {
    azurirajBtn("sljedeci", true, "gray");
  }
  if (mjesec == 0) {
    azurirajBtn("prosli", true, "gray");
  }

  Kalendar.iscrtajKalendar(document.getElementById("kalendar"), mjesec);

  document
    .querySelector("input[name=pocetak]")
    .addEventListener("change", () => {
      pocetak = document.querySelector("input[name=pocetak]").value;
      Kalendar.obojiZauzeca(
        document.getElementById("kalendar"),
        mjesec,
        sala,
        pocetak,
        kraj
      );
    });

  document.querySelector("input[name=kraj]").addEventListener("change", () => {
    kraj = document.querySelector("input[name=kraj]").value;
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      mjesec,
      sala,
      pocetak,
      kraj
    );
  });

  document.getElementById("opcijaSale").addEventListener("change", () => {
    sala = document.getElementById("opcijaSale").value;
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      mjesec,
      sala,
      pocetak,
      kraj
    );
  });

  document.getElementById("prosli").addEventListener("click", () => {
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), --mjesec);
    if (mjesec == 0) {
      azurirajBtn("prosli", true, "gray");
    }
    if (mjesec != 11) {
      azurirajBtn("sljedeci", false, "#066fb6");
    }
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      mjesec,
      document.getElementById("opcijaSale").value,
      document.querySelector("input[name=pocetak]").value,
      document.querySelector("input[name=kraj]").value
    );
  });

  document.getElementById("sljedeci").addEventListener("click", () => {
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), ++mjesec);

    if (mjesec == 11) {
      azurirajBtn("sljedeci", true, "gray");
    }
    if (mjesec != 0) {
      azurirajBtn("prosli", false, "#066fb6");
    }
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      mjesec,
      document.getElementById("opcijaSale").value,
      document.querySelector("input[name=pocetak]").value,
      document.querySelector("input[name=kraj]").value
    );
  });

  function azurirajBtn(id, disabled, boja) {
    const btn = document.getElementById(id);
    btn.disabled = disabled;
    btn.style.backgroundColor = boja;
  }

  return {
    pocetak,
    kraj,
    sala,
    mjesec
  };
})();
