const SLIKA_PO_STRANICI = 3;

let trenutnaStranica = 1;

Pozivi.dajSlike(trenutnaStranica);

let Galerija = (function() {
  slike = [];
  jePosljednjaStranica = false;
  indeksPosljednjeStranice = null;

  function ucitajSlike(slike, jePosljednjaStranica) {
    if (this.slike == undefined) this.slike = slike;
    else this.slike = this.slike.concat(slike);
    this.jePosljednjaStranica = jePosljednjaStranica;
    if (jePosljednjaStranica) {
      indeksPosljednjeStranice = trenutnaStranica;
      azurirajBtn("sSlika", true, "gray");
    }
    if (trenutnaStranica == 1) {
      azurirajBtn("pSlika", true, "gray");
    }
  }

  function ispisiSlike() {
    const prviIndeks = (trenutnaStranica - 1) * SLIKA_PO_STRANICI;
    const galerija = document.getElementById("galerija");
    galerija.innerHTML = "";
    for (let i = prviIndeks; i < prviIndeks + SLIKA_PO_STRANICI; i++) {
      if (this.slike[i]) {
        const image = document.createElement("img");
        image.src = this.slike[i];
        image.alt = "Slika";
        galerija.appendChild(image);
      }
    }
  }

  function getSlike() {
    return this.slike;
  }

  function posljednjaStranica() {
    return this.jePosljednjaStranica;
  }

  return {
    ucitajSlike,
    ispisiSlike,
    getSlike,
    posljednjaStranica
  };
})();

function azurirajBtn(id, disabled, boja) {
  const btn = document.getElementById(id);
  btn.disabled = disabled;
  btn.style.backgroundColor = boja;
}

document.getElementById("pSlika").addEventListener("click", () => {
  trenutnaStranica--;
  if (trenutnaStranica != indeksPosljednjeStranice)
    azurirajBtn("sSlika", false, "#066fb6");
  if (trenutnaStranica == 1) {
    azurirajBtn("pSlika", true, "gray");
  }
  Galerija.ispisiSlike();
});

document.getElementById("sSlika").addEventListener("click", () => {
  trenutnaStranica++;
  if (trenutnaStranica == indeksPosljednjeStranice) {
    azurirajBtn("sSlika", true, "gray");
  }
  if (trenutnaStranica != 1) {
    azurirajBtn("pSlika", false, "#066fb6");
  }
  if (Galerija.getSlike().length >= trenutnaStranica * SLIKA_PO_STRANICI)
    Galerija.ispisiSlike();
  else Pozivi.dajSlike(trenutnaStranica);
});
