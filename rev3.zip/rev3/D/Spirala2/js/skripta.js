
let today = new Date();
let currentMonth = today.getMonth();
let currentYear = 2019; //today.getFullYear();
let selectYear = 2019;
let selectMonth = document.getElementById("mjesec");
let selectedDay = document.getElementById("dan");
let periodicna = document.getElementById("periodicna")
let neperiodicna = document.getElementById("neperiodicna")
let datumZauzeca = document.getElementById("datum")
var myTab = document.getElementById('empTable');
let months = ["Januar", "Februar", "Mart", "April", "Maj", "Juni", "Juli", "Augst", "Septembar", "Octobar", "Novembar", "Decembar"];

let imeMjeseca = document.getElementById("imeMjeseca");


function next() {

    currentMonth = (currentMonth + 1) % 12;
    if(currentMonth === 11){
        document.getElementById("next").disabled = true;
    }
    document.getElementById("previous").disabled = false;
    Kalendar.iscrtajKalendar(currentMonth,currentYear)
}

function previous() {
  
    if (currentMonth === 0) {
        document.getElementById("previous").disabled = true;

    }else {
    
    document.getElementById("next").disabled = false;
    currentMonth =  currentMonth - 1;

    }
    
    Kalendar.iscrtajKalendar(currentMonth,currentYear)
}

function obojiZauzeca() {
   // div za bojanje kalendara
   let calendarDiv =  document.getElementById('calendar-body');
   // clearing all previous cells
   calendarDiv.innerHTML = "";
   // mjesec za bojanje
    currentMonth = parseInt(selectMonth.value);
   
   // sala 
   let sala =  document.getElementById('sala');
   salaOdabrana = sala.value;
 
   // pocetaak i kraj 
   let pocetak =  document.getElementById('pocetak');
   let kraj =  document.getElementById('kraj');
   pocetakString = pocetak.value;
   krajString = kraj.value;

   odabraniDan = parseInt(selectedDay.value);

   vandrednoZauzece = datumZauzeca.value
    let checkPeriodicna;
    if(periodicna.checked == true){
        checkPeriodicna ="true"

    }else {

    }
    
  //console.log("test0 " + checkPeriodicna);
  // console.log("odabrana sala1 " + pocetakString  + " " + krajString)
   //console.log("odabrana sala " + currentMonth  + " " + salaOdabrana)
    Kalendar.obojiZauzeca(calendarDiv,currentMonth,salaOdabrana, pocetak, kraj);
  //Kalendar.iscrtajKalendar(currentMonth,currentYear)

}
var ab ;
function dateListener(e) {
    let arr = e.target.value.split('-');
    if(!this.prevArr)this.prevArr=[];
    if(this.prevArr[0] != arr[0] && arr[0]) {
    //  console.log(`The year was changed from ${this.prevArr[0]} to ${arr[0]}`);
    }
    if(this.prevArr[1] != arr[1] && arr[1]) {
     // console.log(`The month was changed from ${this.prevArr[1]} to ${arr[1]}`);
    }
    if(this.prevArr[2] != arr[2] && arr[2]) {
      ab = arr[2];
     // console.log(`The date was changed from ${this.prevArr[2]} to ${arr[2]}`);
    }
    if(arr[0]) this.prevArr=arr; //If the date is falsey (undefined/empty string), so is the whole array.
  };
  
  document.getElementById("datum").addEventListener("change", dateListener);
function showTableData() {
    document.getElementById('info').innerHTML = "";

    vandrednoZauzece = datumZauzeca.value
    console.log("Tt 0= " + ab )
    // LOOP THROUGH EACH ROW OF THE TABLE AFTER HEADER.
    for (i = 2; i < myTab.rows.length; i++) {

        // GET THE CELLS COLLECTION OF THE CURRENT ROW.
        var objCells = myTab.rows.item(i).cells;

        // LOOP THROUGH EACH CELL OF THE CURENT ROW TO READ CELL VALUES.
        for (var j = 0; j < objCells.length; j++) {
           console.log(objCells.length);
           if (objCells.item(j) === 11){
            
           }
        }
        info.innerHTML = info.innerHTML + '<br />';     // ADD A BREAK (TAG).
    }
}
function pokaziPeriodicneInpute(){
        document.getElementById('periodicniUnos').style.display ='block';
        document.getElementById('neperiodicniUnos').style.display ='none';
}

function pokaziNeperiodicneInpute(){
        document.getElementById('periodicniUnos').style.display = 'none';
        document.getElementById('neperiodicniUnos').style.display = 'block';
}

let Kalendar = (function(){
    //
    //ovdje idu privatni atributi
    //
    let dan ;
    let semestar ;
    let pocetak ;
    let kraj  = "";
    let naziv ;
    let predavac ;
    
    function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj){
    //implementacija ide ovdje
    let firstDay = (new Date(currentYear, mjesec)).getDay() ;
    let daysInMonth = 32 - new Date(currentYear, mjesec, 32).getDate();
     
   let kalendarID =   kalendarRef  //document.getElementById("calendar-body"); // body of the calendar

   // clearing all previous cells
   kalendarID.innerHTML = "";

   // filing data about month and in the page via DOM.
   imeMjeseca.innerHTML = months[mjesec];
   selectMonth.value = mjesec;
   if (firstDay === 0 ){
    firstDay = 7;
    }

   // creating all cells
   let date = 1;
   var pop = 0
   
   
   for (let i = 0; i <= 6; i++) {
       // creates a table row
       let row = document.createElement("tr");
     
       //creating individual cells, filing them up with data.
       for (let j = 1; j <= 7; j++) {
         
         
           if (i === 0 && j < firstDay) {
           
               let cell = document.createElement("td");
               cell.classList.add("prazniDani")
               let cellText = document.createTextNode("");
               cell.appendChild(cellText);
               row.appendChild(cell);
           }
           else if (date > 30) {
               break;
           }

           else {
               let cell = document.createElement("td");
              // console.log("test rad " + j);

               if(periodicna.checked == true){
               // checkPeriodicna ="true"
               if(odabraniDan === j){
                test.push(odabraniDan)
                cell.classList.add("zauzetiDani")
               } else {

                cell.classList.add("slobodniDani")
            
               }

               // console.log("test0 " + checkPeriodicna);
              }else if(neperiodicna.checked == true ){
                
                for (i = 1; i < myTab.rows.length; i++) {
                   
                    // GET THE CELLS COLLECTION OF THE CURRENT ROW.
                    var objCells = myTab.rows.item(i).cells;
                    var test = [];
                    // LOOP THROUGH EACH CELL OF THE CURENT ROW TO READ CELL VALUES.
                    for (var k = 0; k < objCells.length; k++) {
                    
                     cell.classList.add("slobodniDani")
                    } 
                      console.log(": " + test.length)
             
              }      
               
               // pop++
              //  console.log("test fg " + date)
              //  console.log("test j " + ab)
                if(date == ab ) {
                    console.log("test j " + pop + " datum " + ab);
                    test.push(ab)
                    cell.classList.add("zauzetiDani")
                }
                
            }
               let cellText = document.createTextNode(date);

               cell.appendChild(cellText);
               row.appendChild(cell);
               date++;
           }


       }

       kalendarID.appendChild(row);
    }
    }
    function ucitajPodatkeImpl(periodicna, vanredna){
    //implementacija ide ovdje
                  
       
 //  console.log("test rad " + vandrednoZauzece.getDay);
                 for (i = 1; i < myTab.rows.length; i++) {
                   
                    // GET THE CELLS COLLECTION OF THE CURRENT ROW.
                    var objCells = myTab.rows.item(i).cells;
                    var test = [];
                    // LOOP THROUGH EACH CELL OF THE CURENT ROW TO READ CELL VALUES.
                    for (var k = 0; k < objCells.length; k++) {
                     test.push(objCells.item(k).innerHTML)
                     
                      console.log(" ivo i " + k)
                  
                    } 
                  //    console.log(": " + test.length)
             
              }            
           
    }
    function iscrtajKalendarImpl(month, year){
    //implementacija ide ovdje
        
   // appending each row into calendar body.
    let firstDay = (new Date(year, month)).getDay() ;
    let daysInMonth = 32 - new Date(year, month, 32).getDate();

    let tbl = document.getElementById("calendar-body"); // body of the calendar
    let imeMjeseca = document.getElementById("imeMjeseca");
    if (firstDay === 0 ){
        firstDay = 7;
    }

    // clearing all previous cells
    tbl.innerHTML = "";
    imeMjeseca.innerHTML = "";
    // filing data about month and in the page via DOM.
    imeMjeseca.innerHTML = months[month];
    selectMonth.value = month;
   
    // creating all cells
    let date = 1;
    for (let i = 0; i <= 6; i++) {
        // creates a table row
        let row = document.createElement("tr");

        //creating individual cells, filing them up with data.
        for (let j = 1; j <= 7; j++) {
        
            if (i === 0 && j < firstDay) {
              
                let cell = document.createElement("td");
                cell.classList.add("prazniDani")
                let cellText = document.createTextNode("");
                cell.appendChild(cellText);
                row.appendChild(cell);
            }
            else if (date > daysInMonth) {
                break;
            }

            else {
                let cell = document.createElement("td");
                cell.classList.add("slobodniDani")
                let cellText = document.createTextNode(date);
            
                
                cell.appendChild(cellText);
                row.appendChild(cell);
                date++;
            }


        }

        tbl.appendChild(row);
        }
        }
        return {
        obojiZauzeca: obojiZauzecaImpl,
        ucitajPodatke: ucitajPodatkeImpl,
        iscrtajKalendar: iscrtajKalendarImpl
        }
        }());
    //primjer korištenja modula
  //  Kalendar.obojiZauzeca(document.getElementById("calendar-body"),1,"1-15","12:00","13:30");
  
    Kalendar.iscrtajKalendar(currentMonth,currentYear)
