
let assert = chai.assert;
describe('Tabela', function() {
 describe('crtaj()', function() {
   it('should show 30 elements when parameter are month that have 30 days', function() {
	/* 
     Kalendar.iscrtajKalendar(document.getElementById("kalendar"),10);
       let tabela = document.getElementsByTagName ("tbody")[0];						za uspomenu malo ruzniji nacin provjere gledajuci varijablu NEJASNU ali brojacku za mene sada jasnu.
	    let redovi = tabela.getElementsByTagName("tr");								NAPOMENA DA OVO NE ZAHTJEVA INCLUDE CSS ALI SE STVARNO ONDA NA SLICI NE VIDI NISTA. TAKODER MOGU PREBROJATI KLASU MISSDAY DA NE BUDE HARDKODIRANO E TO BI BILO SAMO ODVRATNO ALI NIJE HARDKOD.
		let kolone = redovi[6].getElementsByTagName("td");
     assert.equal(kolone[6].innerHTML, 30,"Broj dana biti 30");*/
	 
	  Kalendar.iscrtajKalendar(document.getElementById("kalendar"),10);
       let tabela = document.getElementsByTagName ("tbody")[0];
	    let redovi = tabela.getElementsByTagName("tr");
		
		let brojPrikazanih = 0;
		for(let k=1;k<redovi.length;k++)
		{
			let kolone= redovi[k].getElementsByTagName("td");
			for(let i=0;i<kolone.length;i++)
			{
				 let stil = window.getComputedStyle(kolone[i])
				//if(stil.visibility!=='hidden') brojPrikazanih++; //ako ne smijem includat css u testove
				if(kolone[i].className!=="missDay") brojPrikazanih++; 
			}
			
		}
		
       
       
          
       
       assert.equal(brojPrikazanih, 30,"Broj dana treba biti 30");
	 
   });
   it('should draw 31 dates when month has 31 days', function() {
       
       Kalendar.iscrtajKalendar(document.getElementById("kalendar"),11);
       let tabela = document.getElementsByTagName ("tbody")[0];
	    let redovi = tabela.getElementsByTagName("tr");
		
		let brojPrikazanih = 0;
		for(let k=1;k<redovi.length;k++)
		{
			let kolone= redovi[k].getElementsByTagName("td");
			for(let i=0;i<kolone.length;i++)
			{
				 let stil = window.getComputedStyle(kolone[i])
				//if(stil.visibility!=='hidden') brojPrikazanih++;   ISTO KAO GORE AKO NE SMIJE INCLUDE CSs
				if(kolone[i].className!=="missDay") brojPrikazanih++; 
			}
			
		}		            
       assert.equal(brojPrikazanih, 31,"Broj dana treba biti 31");
     });
	 it('Za trenutni mjesec prvi dan u petak treba biti', function() {
       var date=new Date();
       Kalendar.iscrtajKalendar(document.getElementById("kalendar"),date.getMonth());
       let tabela = document.getElementsByTagName ("tbody")[0];
	    let redovi = tabela.getElementsByTagName("tr");
		let kolone= redovi[1].getElementsByTagName("td");
		let prvidan=-1;
			for(let i=0;i<kolone.length;i++)
			if(kolone[i].innerHTML == "1")
					prvidan=i+1;
	            
       assert.equal(prvidan, 5,"Prvi dan treba biti na peti u sedmici tj petak");
     });
	 
	 it('Za trenutni mjesec zadnji 30 dan u subotu treba biti', function() {
       var date=new Date();
       Kalendar.iscrtajKalendar(document.getElementById("kalendar"),date.getMonth());
       let tabela = document.getElementsByTagName ("tbody")[0];
	   let redovi = tabela.getElementsByTagName("tr");
	   let zadnjidan=-1;
		//let brojPrikazanih = 0;
		for(let k=1;k<redovi.length;k++)
		{
			let kolone= redovi[k].getElementsByTagName("td");
			for(let i=0;i<kolone.length;i++)
			{
				 if(kolone[i].innerHTML =="30")
				 {
					 zadnjidan=i+1;
					 i=10;
					 k=10; // prekid obje petlje jer se nasao prvi 30ti, to sto ostali imaju istu vrijednost je radi kraceg koda u JS, svakako su hidden.
				 }
			}	
		}		            
       assert.equal(zadnjidan, 6,"Subota za zadnji dan u mjesecu treba biti");
     });
	 
	  it('Za januar dani idu od 1 do 31 pocevsi od utorka', function() {
       var date=new Date();
       Kalendar.iscrtajKalendar(document.getElementById("kalendar"),0);
	   // dovde dosao nakon ovog jos sam izmislit 2 testa i tjt
		let tabela = document.getElementsByTagName ("tbody")[0];
	    let redovi = tabela.getElementsByTagName("tr");
		let brojPrikazanih = 0;
		let prvidan=-1;
		for(let k=1;k<redovi.length;k++)
		{
			let kolone= redovi[k].getElementsByTagName("td");
			for(let i=0;i<kolone.length;i++)
			{
				 let stil = window.getComputedStyle(kolone[i])
				 if(kolone[i].className!=="missDay") brojPrikazanih++; 
			}
		}		

		let kolona = redovi[1].getElementsByTagName("td");
		for(let k=0;k<kolona.length;k++)
		{
			
			 if(kolona[k].innerHTML =="1")
			 {
				 prvidan=k+1;
				 break;
			 }
		}
				
       assert.equal(prvidan, 2,"Utorak prvi dan");
	   assert.equal(brojPrikazanih, 31,"Dani idu do 31"); // mislim ovo je previse neprecizno kako testirati, dani idu od 1 do 31 a  iponovljen test je kao ovi gore isto sve
     });
	 
	 it('+1 test Na februaru treba biti 28 dana', function() {
       
       Kalendar.iscrtajKalendar(document.getElementById("kalendar"),1);
       let tabela = document.getElementsByTagName ("tbody")[0];
	    let redovi = tabela.getElementsByTagName("tr");
		
		let brojPrikazanih = 0;
		for(let k=1;k<redovi.length;k++)
		{
			let kolone= redovi[k].getElementsByTagName("td");
			for(let i=0;i<kolone.length;i++)
			{
				 let stil = window.getComputedStyle(kolone[i])
				//if(stil.visibility!=='hidden') brojPrikazanih++;   ISTO KAO GORE AKO NE SMIJE INCLUDE CSs
				if(kolone[i].className!=="missDay") brojPrikazanih++; 
			}
			
		}		            
       assert.equal(brojPrikazanih, 28,"Broj dana treba biti 31");
     });
	 
	  it('+2 test Na Decembru treba biti 6 redova tabele kalendara', function() {
       
       Kalendar.iscrtajKalendar(document.getElementById("kalendar"),11);
       let tabela = document.getElementsByTagName ("tbody")[0];
	   let redovi = tabela.getElementsByTagName("tr");
		let brojPrikazanih = 0;
		let brojRedova = 0;
		for(let k=1;k<redovi.length;k++)
		{
			let kolone= redovi[k].getElementsByTagName("td");
			for(let i=0;i<kolone.length;i++)
			{
				 if(kolone[i].className!=="missDay")
				 {brojRedova++; break;}
			}
		}		            
       assert.equal(brojRedova, 6,"Broj redova sa datumima treba biti 6");
     });
	 
	 
	 

	 // zadatak 2
	 it('Z1: Pozivanje obojiZauzeca kada podaci nisu učitani: očekivana vrijednost da se ne oboji niti jedan dan', function() {
    var date=new Date();
	   Kalendar.ucitajPodatke({},{}); // morao staviti jer u windows on load ucitava ono sto rezervacija.js treba da ucita..
	  Kalendar.obojiZauzeca(document.getElementById("kalendar"),date.getMonth(),"VA1", "00:00","23:59"  );

	   let tabela = document.getElementsByTagName ("tbody")[0];
	   let redovi = tabela.getElementsByTagName("tr");
		let uredu = 1;
		for(let k=1;k<redovi.length;k++)
		{
			let kolone= redovi[k].getElementsByTagName("td");
			for(let i=0;i<kolone.length;i++)
			{
				 if(kolone[i].className=="zauzetDan")
				 { uredu=0; }
				
			}
		}		            
       assert.equal(uredu, 1,"Nijedan nema klasu zauzetDan");
     });
	 
	 	   it('Z2:Treba da oboji peticu novembra', function() {
     var date=new Date();
	var tmp1 = {datum:"05.11.2019", pocetak:"11:00", kraj:"18:10", naziv:"VA1",predavac:"Neko Nekic"};
	var tmp2 = {datum:"05.11.2019", pocetak:"11:00", kraj:"14:30", naziv:"VA1",predavac:"Smaras Bgm"};
	var niz = [tmp1,tmp2]; // dva ista ubacena
	   Kalendar.ucitajPodatke({},niz); // morao staviti jer u windows on load ucitava ono sto rezervacija.js treba da ucita..
	  Kalendar.obojiZauzeca(document.getElementById("kalendar"),date.getMonth(),"VA1", "00:00","23:59"  );

	   let tabela = document.getElementsByTagName ("tbody")[0];
	   let redovi = tabela.getElementsByTagName("tr");
		let uredu = 0;
		for(let k=1;k<redovi.length;k++)
		{
			let kolone= redovi[k].getElementsByTagName("td");
			for(let i=0;i<kolone.length;i++)
			{
				
				 if(kolone[i].className=="zauzetDan" && kolone[i].innerHTML=='5')
				 { uredu=1; }
			}
		}		            
       assert.equal(uredu, 1,"Obojen je");
     });
	  	   it('Z3:Treba da ne oboji ovaj semestar periodicno', function() {
		var date=new Date();
		var rmp2 = { dan: "2", semestar: "ljetni", pocetak: "08:00", kraj:"22:00", naziv:"VA1", predavac:"huse fatkic" };
		var niz = [rmp2];
		Kalendar.ucitajPodatke(niz,{}); // morao staviti jer u windows on load ucitava ono sto rezervacija.js treba da ucita..
		Kalendar.obojiZauzeca(document.getElementById("kalendar"),4,"VA1", "00:00","23:59"  );

	   let tabela = document.getElementsByTagName ("tbody")[0];
	   let redovi = tabela.getElementsByTagName("tr");
		let uredu = 1;
		for(let k=1;k<redovi.length;k++)
		{
			let kolone= redovi[k].getElementsByTagName("td");
			console.log(kolone[2].innerHTML);
			if(kolone[2].className!="zauzetDan" && kolone[2].className!="missDay")
			uredu=0;
		}		            
       assert.equal(uredu, 0,"Obojen je");
     });
	 
	 it('Z4:Treba da ne oboji u drugom mjesecu', function() {
     var date=new Date();
	var tmp1 = {datum:"05.12.2019", pocetak:"11:00", kraj:"18:10", naziv:"VA1",predavac:"Neko Nekic"};
	var niz = [tmp1]; // dva ista ubacena
	   Kalendar.ucitajPodatke({},niz); // morao staviti jer u windows on load ucitava ono sto rezervacija.js treba da ucita..
	  Kalendar.obojiZauzeca(document.getElementById("kalendar"),date.getMonth(),"VA1", "00:00","23:59"  );

	   let tabela = document.getElementsByTagName ("tbody")[0];
	   let redovi = tabela.getElementsByTagName("tr");
		let uredu = 1;
		for(let k=1;k<redovi.length;k++)
		{
			let kolone= redovi[k].getElementsByTagName("td");
			for(let i=0;i<kolone.length;i++)
			{
				 if(kolone[i].className=="zauzetDan" && kolone[i].innerHTML=='5')
				 { uredu=0; }
			}
		}		            
       assert.equal(uredu, 1,"Nije obojen ");
     });
	 
	   it('Z5:Treba da su svi obojeni jer ima zauzece', function() {
     var date=new Date();
	
	var rmp1 = { dan: "0", semestar: "zimski", pocetak: "08:00", kraj:"22:00", naziv:"VA1", predavac:"huse fatkic" };
	var rmp2 = { dan: "1", semestar: "zimski", pocetak: "08:00", kraj:"22:00", naziv:"VA1", predavac:"huse fatkic" };
	var rmp3 = { dan: "2", semestar: "zimski", pocetak: "08:00", kraj:"22:00", naziv:"VA1", predavac:"huse fatkic" };
	var rmp4 = { dan: "3", semestar: "zimski", pocetak: "08:00", kraj:"22:00", naziv:"VA1", predavac:"huse fatkic" };
	var rmp5 = { dan: "4", semestar: "zimski", pocetak: "08:00", kraj:"22:00", naziv:"VA1", predavac:"huse fatkic" };
	var rmp6 = { dan: "5", semestar: "zimski", pocetak: "08:00", kraj:"22:00", naziv:"VA1", predavac:"huse fatkic" };
	var rmp7 = { dan: "6", semestar: "zimski", pocetak: "08:00", kraj:"22:00", naziv:"VA1", predavac:"huse fatkic" };
	var niz = [rmp1,rmp2,rmp3,rmp4,rmp5,rmp6,rmp7];
		
	   Kalendar.ucitajPodatke(niz,{}); // morao staviti jer u windows on load ucitava ono sto rezervacija.js treba da ucita..
	  Kalendar.obojiZauzeca(document.getElementById("kalendar"),date.getMonth(),"VA1", "00:00","23:59"  );

	   let tabela = document.getElementsByTagName ("tbody")[0];
	   let redovi = tabela.getElementsByTagName("tr");
		let uredu = 1;
		for(let k=1;k<redovi.length;k++)
		{
			let kolone= redovi[k].getElementsByTagName("td");
			for(let i=0;i<kolone.length;i++)
			{
				 if(kolone[i].className!="zauzetDan" && kolone[i].className!="missDay" )
				 { uredu=0; }
			}
		}		            
       assert.equal(uredu, 1,"Obojen je citav");
     });
	/*Pozivanje obojiZauzece kada u podacima postoji zauzeće termina ali u drugom mjesecu: očekivano
je da se ne oboji zauzeće
*/
 });
});
