
window.onload = function() {
	var date = new Date();
	
	var el=document.getElementById("grupa3");
	var kod="<button type='button' id='prButton'> Prethodni </button>";   // Razlog je radi onih testova ali je bolje da sam u html testovi dodao kod, ovako manje citko.
	kod+="<button type='button' id='nxButton'> Sljedeći</button>";
	el.innerHTML=kod;
	
	Kalendar.iscrtajKalendar(document.getElementById("kalendar"),date.getMonth());  // za trenutni mjesec default
	
    var element = document.getElementById('prButton');
	element.addEventListener('click',Kalendar.buttonPrethodni);  // event listeneri za pomjeranje kalendara
	var element = document.getElementById('nxButton');
	element.addEventListener('click',Kalendar.buttonSljedeci); 
	
	var tmp1 = {datum:"05.10.2019", pocetak:"11:00", kraj:"18:10", naziv:"VA1",predavac:"Neko Nekic"};
	var tmp2 = {datum:"16.11.2019", pocetak:"12:00", kraj:"14:30", naziv:"VA1",predavac:"Smaras Bgm"};
	var tmp3 = {datum:"19.11.2019", pocetak:"12:00", kraj:"14:30", naziv:"VA1",predavac:"Smaras Bgm2"};
	var tmp4 = {datum:"30.11.2022", pocetak:"12:00", kraj:"14:30", naziv:"VA1",predavac:"Smaras Bgm3"};
	var tmp5 = {datum:"25.12.2019", pocetak:"12:00", kraj:"14:30", naziv:"VA1",predavac:"Smaras Bgm4"};
	var tmp6 = {datum:"16.11.2020", pocetak:"12:00", kraj:"14:30", naziv:"VA2",predavac:"Smaras Bgm5"};
	var tmp7 = {datum:"03.11.2019", pocetak:"12:00", kraj:"14:30", naziv:"VA2",predavac:"Smaras Bgm3"};
	
	var rmp1 = { dan: "4", semestar: "zimski", pocetak: "12:00", kraj:"22:00", naziv:"VA1", predavac:"huse fatkic" };
	var rmp2 = { dan: "2", semestar: "ljetni", pocetak: "08:00", kraj:"22:00", naziv:"VA1", predavac:"huse fatkic" };			// HARDKODIRANI PODACI DOK NE DODE BAZA
	
	var vanredniniz = [ tmp1,tmp2,tmp3,tmp4,tmp5,tmp6,tmp7 ];
	var redovniniz = [rmp1,rmp2];
	Kalendar.ucitajPodatke(redovniniz,vanredniniz); 
	
					
	var list = document.getElementById("listaSala").getElementsByTagName("select")[0];
	list.addEventListener("change",Kalendar.promjena);
	var inp1 = document.getElementById("pzauzece");
	inp1.addEventListener("change",Kalendar.promjena);   // dodavanje istog event listenera za on change
	var inp2 = document.getElementById("kzauzece");	
	inp2.addEventListener("change",Kalendar.promjena);
	
	};


/* MODUL KALENDAR*/
  let Kalendar = (function(){
//
//ovdje idu privatni atributi
var mj;
var nizvanredna;
var nizredovna;
//


function ucitajPodatkeImpl(periodicna, vanredna){
//implementacija ide ovdje i prvo ovu uradi od ove dvije.
nizvanredna=vanredna;
nizredovna=periodicna;
}



function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj){
	
	
	Kalendar.iscrtajKalendar(document.getElementById("kalendar"),mjesec); // optimalnije je sad proc kroz svaki element i postavit mu outerHTML samo na dv dv, ali sad mi je citkost bitnija od optimalnosti.
	
	// moglo se izbjec da pocetak rastvaram ali dosta sam stringova dirao necu da bude necitko.
	
	if(kraj.split(/\:+/).slice(0,2)[1]=="" || kraj.split(/\:+/).slice(0,2)[0] =="" || pocetak.split(/\:+/).slice(0,2)[1]=="" || pocetak.split(/\:+/).slice(0,2)[0]=="" )
	return;
		
var psati = parseInt(pocetak.split(/\:+/).slice(0,2)[0]);
var pminute = parseInt(pocetak.split(/\:+/).slice(0,2)[1]);  // Vrijeme koje je ucitano sa tih inputa a funkcija primila kao stringove.
var ksati = parseInt(kraj.split(/\:+/).slice(0,2)[0]);
var kminute = parseInt(kraj.split(/\:+/).slice(0,2)[1]);
 

   let tabela = kalendarRef.getElementsByTagName ("tbody")[0]; // uzmemo tabelu
	let redovi = tabela.getElementsByTagName("tr");  // sve redove tabele
		//let brojPrikazanih = 0;
		for(let k=1;k<redovi.length;k++) // jer su dani nulti red, prolazimo kroz ostale redove
		{
			let kolone= redovi[k].getElementsByTagName("td");  // uzimamo sve kolone K-TOG reda.
			for(let j=0;j<kolone.length;j++)
			{
				for (var i=0;i<nizvanredna.length;i++) // PADACE NA GRANICNIM SLUCAJEVIMA KAD JE PRAZNO POLJE 1100% 
				{
					/* Dobavljanje datuma i vremena i-tog vanrednog zauzeca */
					var date = nizvanredna[i]["datum"];
					var ptime =  nizvanredna[i]["pocetak"];  
					var ktime =  nizvanredna[i]["kraj"];
					var presjekvremena=false;
					date=date.split(/\.+/).slice(0,3);  // date[0  1 2 redom za dan mjesec godina izdvojeno lijepo 
					ptime=ptime.split(/\:+/).slice(0,2); //ptime[0] i ptime[1] za sate i minute redom, moze parseInt radi 05 ako treba
					ktime=ktime.split(/\:+/).slice(0,2);

		// da ne bude obojeno ili mora biti kraj do 12:00 ili pocetak OD 14:30, necu provjeravati da je neko obrno pocetak i kraj 100% greska za kriticne validacije
		
					if(!  (    (  ksati<parseInt(ptime[0]) || ( ksati==parseInt(ptime[0]) && kminute<=parseInt(ptime[1]) )  )   ||   (  psati> parseInt(ktime[0]) || ( psati==parseInt(ktime[0]) && pminute>=parseInt(ktime[1]) )   )    )   )
						presjekvremena=true;
		
	
					if(/*inp1.value!="" && inp2.value!="" &&*/ sala == nizvanredna[i]["naziv"] && (mjesec+1)==parseInt(date[1]) && presjekvremena==true && kolone[j].innerHTML==parseInt(date[0]) && kolone[j].className!='missDay' && date[2]==2019 )   // pazi da mjesec ono posto je jedan manje se podudara
					{
						
						kolone[j].outerHTML="<td class='zauzetDan'>"+ kolone[j].innerHTML +"</td>"; // moglo se igrat sa splitom ali posto nema unutra klasa nije frka. 50% WARNING
						break;
					}
	
	
				}  
				
				
				
				for (var i=0; i<nizredovna.length;i++)
				{
					var dan = nizredovna[i]["dan"]; // od 0 do 6 pon-petak
					var semestar = nizredovna[i]["semestar"];
					var ptime =  nizredovna[i]["pocetak"];
					var ktime =  nizredovna[i]["kraj"];
					var presjekvremena=false;
					
					ptime=ptime.split(/\:+/).slice(0,2); //ptime[0] i ptime[1] za sate i minute redom, moze parseInt radi 05 ako treba
					ktime=ktime.split(/\:+/).slice(0,2);
					if (! (  (     ksati< parseInt(ptime[0]) || ( ksati==parseInt(ptime[0]) && kminute<=parseInt(ptime[1]) )    )   ||  (     psati> parseInt(ktime[0]) || ( psati==parseInt(ktime[0]) && pminute>=parseInt(ktime[1]) )    )  )) //stavljen !
					presjekvremena=true;
					if(/*inp1.value!="" && inp2.value!="" && */sala == nizredovna[i]["naziv"] && presjekvremena==true && kolone[j].className!='missDay' && ( semestar=="zimski" && mj>=9 || (semestar=="ljetni" && mj>=1 && mj<=5 && 2==3/*UVIJEK FALSE JER TEK IDUCA GODINA JE TAJ SEMESTAR A NE OVA*/) ) &&  dan==j   )
					{
						
						kolone[j].outerHTML="<td class='zauzetDan'>"+ kolone[j].innerHTML +"</td>"; // moglo se igrat sa splitom ali posto nema unutra klasa nije frka. 50% WARNING
						break;
					}
				}
				
					
			}
			 // izmedu petlji prolaza kroz tabelu
		}


}





function iscrtajKalendarImpl(kalendarRef, mjesec){

mj=mjesec; // setovanje privatnog atributa

/* Setovanje izgleda kursora na zabranjeno kao intiuitivno da se ne moze ici dalje od decembra i januara */
if(mj==11)document.getElementById("nxButton").style.cursor = "not-allowed";
else document.getElementById("nxButton").style.cursor = "pointer";
if(mj==0) document.getElementById("prButton").style.cursor = "not-allowed";
else document.getElementById("prButton").style.cursor = "pointer";
/* */

/* Dobijanje brojcane vrijednosti rednog dana u sedmici kao i broj ukupnog dana mjeseca */
var date = new Date();
var prviDan = new Date(date.getFullYear(), mj, 1).getDay();  // u brojevima prvi dan mjeseca 5 za petak
if(prviDan == 0) prviDan = 7;
var zadnjiDan =  new Date(date.getFullYear(), mj+1, 0).getDate(); // 0 je zadnji dan proslog mjeseca.
if(zadnjiDan == 0) zadnjiDan = 7; 
/* */


/*POCETAK CRTANJA KALENDARA*/

var str  = NumToMonth(mj); // Na osnovu trenutnog mjeseca ispisuje label iznad kalendara na bosanskom.
kalendarRef.innerHTML="<label for= 'kalendar'> "+str+": </label> ";

var html = "<table class='kalendartabela'> " +
"<tr>"+
"<th>PON</th>"+
"<th>UTO</th>"+
"<th>SRI</th>"+
"<th>CET</th>"+
"<th>PET</th>"+
"<th>SUB</th>"+
"<th>NED</th>"+
"</tr>";

var Miss="";
var brojac=0;
for( var i=1; i<=6;i++)  // 6 zato sto neki mjeseci imaju dane u 6 sedmica. one koji nemaju stavicemo missday klasu da se ne prikazu. 
{
	html+="<tr>";

		for(var j=1;j<=7;j++)
		{
			if(i==1 && j<prviDan || brojac>=zadnjiDan) //RAZLOG OVOME JE STO NEKI MJESECI IMAJU 5 NEKI 6 I NE ZELIM DA MI SKACE DUGME PRETHODNI I SLJEDECI GORE DOLE ZA RAZLICITE MJESECE. 
			{
				Miss= " class='missDay'"
			}
			else {Miss =""; brojac++; }
			
			html+= "<td" + Miss + ">" + brojac + "</td>"; 		 
		}
	 
	html+="</tr>";
}

kalendarRef.innerHTML+=html+"</table>";
/*KRAJ CRTANJA*/

}


/* Pomocna funkcija koja pretvara u bosansko ime mjeseca */
function NumToMonth (broj) 
{
	if (broj == "0") return "Januar";
	else if(broj == "1") return "Februar";
	else if(broj == "2") return "Mart";
	else if(broj == "3") return "April";
	else if(broj == "4") return "Maj";
	else if(broj == "5") return "Juni";
	else if(broj == "6") return "Juli";
	else if(broj == "7") return "August";
	else if(broj == "8") return "Septembar";
	else if(broj == "9") return "Oktobar";
	else if(broj == "10") return "Novembar";
	else if(broj == "11") return "Decembar";
	else
	{
		console.log("greska u imenu mjeseca");
		return "";
	}
}

function buttonPrethodni ()
{
	if(mj>0)
	{
		mj = mj-1;
		//var list = document.getElementById("listaSala").getElementsByTagName("select")[0].selectedIndex=0;  Ali to ne zelimo, zavisi sve sta zelimo impl.
		//Kalendar.iscrtajKalendar(document.getElementById("kalendar"),mj);   Obrisano jer promjena poziva zapravo crtanje kalendara za mj atribut.
		promjena();
	}
		else {console.log("mjesec je vec januar ne moze lijevo");}
}

function buttonSljedeci ()
{
	
	if(mj<11)
	{
		mj = mj+1;
		//var list = document.getElementById("listaSala").getElementsByTagName("select")[0].selectedIndex=0;
		//Kalendar.iscrtajKalendar(document.getElementById("kalendar"),mj);    
		promjena();
	}
		else {console.log("mjesec je vec decembar ne moze desno");}
		
		
}
  
function promjena ()
{
	
	var list = document.getElementById("listaSala").getElementsByTagName("select")[0];
	var izabraniEl= list.options[list.selectedIndex].text;
	var inp1 = document.getElementById("pzauzece");   // Stavljene default vrijednosti za vrijeme hardkod
	var inp2 = document.getElementById("kzauzece");
	Kalendar.obojiZauzeca(document.getElementById("kalendar"),mj,izabraniEl, inp1.value,inp2.value  );
		
}
  
return {
obojiZauzeca: obojiZauzecaImpl,
ucitajPodatke: ucitajPodatkeImpl,
iscrtajKalendar: iscrtajKalendarImpl,


NumToMonth:NumToMonth,
buttonPrethodni:buttonPrethodni,
buttonSljedeci:buttonSljedeci,
promjena:promjena,
}
}());

/* KRAJ MODULA*/