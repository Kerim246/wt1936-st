#!/bin/bash
FILE="pocetna"
MOBILE="mobile"$FILE
galen mutate $FILE.gspec --url file:///Users/vedad/fax/wt/wt1917336/$FILE.html --size 1200x800 --offset 5 --htmlreport mutation-report
galen mutate $MOBILE.gspec --url file:///Users/vedad/fax/wt/wt1917336/$FILE.html --size 600x600 --offset 5 --htmlreport mutation-report

FILE="rezervacija"
MOBILE="mobile"$FILE
galen mutate $FILE.gspec --url file:///Users/vedad/fax/wt/wt1917336/$FILE.html --size 1200x800 --offset 5 --htmlreport mutation-report
galen mutate $MOBILE.gspec --url file:///Users/vedad/fax/wt/wt1917336/$FILE.html --size 600x600 --offset 5 --htmlreport mutation-report

FILE="sale"
MOBILE="mobile"$FILE
galen mutate $FILE.gspec --url file:///Users/vedad/fax/wt/wt1917336/$FILE.html --size 1200x800 --offset 5 --htmlreport mutation-report
galen mutate $MOBILE.gspec --url file:///Users/vedad/fax/wt/wt1917336/$FILE.html --size 600x600 --offset 5 --htmlreport mutation-report

FILE="unos"
MOBILE="mobile"$FILE
galen mutate $FILE.gspec --url file:///Users/vedad/fax/wt/wt1917336/$FILE.html --size 1200x800 --offset 5 --htmlreport mutation-report
galen mutate $MOBILE.gspec --url file:///Users/vedad/fax/wt/wt1917336/$FILE.html --size 600x600 --offset 5 --htmlreport mutation-report
