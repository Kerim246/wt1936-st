var trenutni = new Date().getMonth();
var kalendar = document.getElementsByClassName("tabelaRezervacija")[0];

let Kalendar = (function() {
  var mjeseci = [
    "Januar",
    "Februar",
    "Mart",
    "April",
    "Maj",
    "Juni",
    "Juli",
    "August",
    "Septembar",
    "Oktobar",
    "Novembar",
    "Decembar"
  ];
  var periodicnaPodaci, vanredniPodaci;

  function ucitajPodatkeImpl(periodicna, vanredni) {
    periodicnaPodaci = periodicna;
    vanredniPodaci = vanredni;
  }

  function ucitajSaForme() {
    let lista = document.getElementById("listaSala");
    let izabranaSala = lista.options[lista.selectedIndex].text;
    let izabraniPocetak = document.getElementById("pocetak").value;
    let izabraniKraj = document.getElementById("kraj").value;
    if (
      izabranaSala !== "" &&
      izabraniPocetak != "" &&
      izabraniKraj != "" &&
      izabraniPocetak < izabraniKraj
    ) {
      obojiZauzecaImpl(
        kalendar,
        trenutni + 1,
        izabranaSala,
        izabraniPocetak,
        izabraniKraj
      );
    }
  }

  function trenutniSemestar() {
    if (trenutni >= 9 || trenutni === 0) return "zimski";
    else if (trenutni >= 1 && trenutni <= 5) return "ljetni";
    return "";
  }

  function imaKolizijuTermina(p1, k1, p2, k2) {
    return !(k1 < p2 || k2 < p1);
  }

  function obojiZauzecaImpl(
    kalendarRef,
    mjesec,
    izabranaSala,
    izabraniPocetak,
    izabraniKraj
  ) {
    Kalendar.iscrtajKalendar(
      document.getElementsByClassName("tabelaRezervacija")[0],
      mjesec - 1
    );
    if (
      periodicnaPodaci === null ||
      typeof periodicnaPodaci === "undefined" ||
      vanredniPodaci === null ||
      typeof vanredniPodaci === "undefined"
    )
      return;
    if (mjesec < 10) mjesec = "0" + mjesec.toString();
    let tabela = document.getElementById("sadrzajKalendara");
    for (let i = 0; i < periodicnaPodaci.length; i++) {
      if (
        periodicnaPodaci[i].semestar === trenutniSemestar() &&
        periodicnaPodaci[i].naziv === izabranaSala &&
        imaKolizijuTermina(
          periodicnaPodaci[i].pocetak,
          periodicnaPodaci[i].kraj,
          izabraniPocetak,
          izabraniKraj
        )
      ) {
        for (let k = 0; k < tabela.rows.length; k++) {
          for (let l = 0; l < tabela.rows[k].cells.length; l++) {
            if (
              !tabela.rows[k].cells[l].classList.contains("skrivenaCelija") &&
              l === periodicnaPodaci[i].dan
            ) {
              tabela.rows[k].cells[l].classList.add("zauzeta");
            }
          }
        }
      }
    }
    for (let j = 0; j < vanredniPodaci.length; j++) {
      if (
        vanredniPodaci[j].datum.substr(3, 2) == mjesec.toString() &&
        vanredniPodaci[j].naziv === izabranaSala &&
        imaKolizijuTermina(
          vanredniPodaci[j].pocetak,
          vanredniPodaci[j].kraj,
          izabraniPocetak,
          izabraniKraj
        )
      ) {
        let dan = parseInt(vanredniPodaci[j].datum.substr(0, 2), 10);
        let brojac = 0;
        for (let k = 0; k < tabela.rows.length; k++) {
          for (let l = 0; l < tabela.rows[k].cells.length; l++) {
            if (tabela.rows[k].cells[l].classList.contains("skrivenaCelija"))
              continue;
            brojac++;
            if (brojac === dan)
              tabela.rows[k].cells[l].classList.add("zauzeta");
          }
        }
      }
    }
  }

  function iscrtajKalendarImpl(kalendarRef, mjesec) {
    var prviDan = new Date(2019, mjesec).getDay();
    prviDan--;
    if (prviDan === -1) prviDan = 6;

    var brojDana = new Date(2019, mjesec + 1, 0).getDate();

    let naslov = document.getElementById("naslov");
    naslov.innerHTML = mjeseci[mjesec];

    let tabela = document.getElementById("sadrzajKalendara");
    tabela.innerHTML = "";

    let dan = 1;
    for (let i = 0; i < 7; i++) {
      let red = document.createElement("tr");
      for (let j = 0; j < 7; j++) {
        if (dan > brojDana) break;
        else if (i === 0 && j < prviDan) {
          let celija = document.createElement("td");
          let unutrasnjostCelije = document.createTextNode("");
          celija.classList.add("skrivenaCelija");
          celija.appendChild(unutrasnjostCelije);
          red.appendChild(celija);
        } else {
          let celija = document.createElement("td");
          let unutrasnjostCelije = document.createTextNode(dan);
          celija.appendChild(unutrasnjostCelije);
          celija.classList.add("slobodna");
          red.appendChild(celija);
          dan++;
        }
      }
      tabela.appendChild(red);
    }
  }

  return {
    obojiZauzeca: obojiZauzecaImpl,
    ucitajPodatke: ucitajPodatkeImpl,
    ucitaj: ucitajSaForme,
    iscrtajKalendar: iscrtajKalendarImpl
  };
})();

function promijeniMjesec(pomak) {
  let naslov = document.getElementById("naslov").innerHTML;
  if (
    (naslov === "Januar" && pomak.data === -1) ||
    (naslov === "Decembar" && pomak.data === 1)
  )
    return;
  trenutni += pomak.data;
  Kalendar.iscrtajKalendar(
    document.getElementsByClassName("tabelaRezervacija")[0],
    trenutni
  );
  Kalendar.ucitaj();
}

$(function() {
  Kalendar.iscrtajKalendar(
    document.getElementsByClassName("tabelaRezervacija")[0],
    trenutni
  );

  Kalendar.ucitajPodatke(p, v);

  $("#forma").change(Kalendar.ucitaj);
  $("#lijevi").click(-1, promijeniMjesec);
  $("#desni").click(1, promijeniMjesec);
});

let p = [
  {
    dan: 1,
    semestar: "ljetni",
    pocetak: "08:00",
    kraj: "10:00",
    naziv: "VA1",
    predavac: "Pero Peric"
  },
  {
    dan: 3,
    semestar: "zimski",
    pocetak: "11:00",
    kraj: "14:00",
    naziv: "VA2",
    predavac: "Miki Maus"
  }
];

let v = [
  {
    datum: "15.10.2019",
    pocetak: "08:00",
    kraj: "10:00",
    naziv: "VA1",
    predavac: "Pero Peric"
  },
  {
    datum: "15.11.2019",
    pocetak: "09:00",
    kraj: "10:00",
    naziv: "MA",
    predavac: "Miki Maus"
  },
  {
    datum: "01.02.2019",
    pocetak: "09:00",
    kraj: "10:00",
    naziv: "MA",
    predavac: "Miki Maus"
  }
];
